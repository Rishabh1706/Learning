# 🎯 Google Ads & Spanner: Master Globally Distributed SQL Databases

> **Learn how Google supports 4.77 billion users with a single SQL database system**

## 📚 Learning Objectives

By the end of this module, you will:
- Understand the limitations of traditional MySQL at scale
- Master Google Spanner's globally distributed architecture
- Implement ACID properties in distributed systems
- Design systems with global consistency and high availability
- Apply TrueTime concepts for distributed synchronization

---

## 🏁 Prerequisites

### **Required Knowledge**
- Basic SQL and database concepts
- Understanding of ACID properties
- Familiarity with distributed systems basics
- Basic networking concepts

### **Recommended Reading**
- Database systems fundamentals
- CAP theorem basics
- Distributed consensus algorithms

---

## 📖 Module 1: The Problem - MySQL at Scale

### **1.1 Google's Growth Story**
```
Timeline:
1996: Google founded as university project
2000: AdWords launched (Google's main revenue source)
2004: IPO - explosive growth begins
2023: $237 billion revenue from ads
2024: 4.77 billion users globally
```

### **1.2 Initial Architecture**
```sql
-- Simple MySQL setup for AdWords
CREATE DATABASE adwords;

CREATE TABLE campaigns (
    id BIGINT PRIMARY KEY,
    advertiser_id BIGINT,
    name VARCHAR(255),
    budget DECIMAL(10,2),
    status ENUM('active', 'paused', 'deleted')
);

CREATE TABLE ads (
    id BIGINT PRIMARY KEY,
    campaign_id BIGINT,
    title VARCHAR(100),
    description TEXT,
    target_url VARCHAR(500),
    FOREIGN KEY (campaign_id) REFERENCES campaigns(id)
);
```

### **1.3 Scaling Challenges**

#### **Challenge 1: Storage Explosion**
```
Growth Pattern:
Year 1: 1GB of data
Year 2: 10GB of data
Year 3: 100GB of data
Year 4: 1TB of data
Year 5: 10TB+ of data

Problem: Single MySQL server couldn't handle storage needs
```

#### **Challenge 2: Read/Write Performance**
```
Performance Bottlenecks:
- Single master for all writes
- Read replicas lagging behind
- Complex queries timing out
- Connection pool exhaustion
```

#### **Challenge 3: Sharding Complexity**
```python
# Manual sharding implementation
def get_shard(advertiser_id):
    return f"adwords_shard_{advertiser_id % 10}"

def write_campaign(campaign_data):
    shard = get_shard(campaign_data['advertiser_id'])
    db = connect_to_shard(shard)
    return db.insert('campaigns', campaign_data)

def read_campaign(campaign_id, advertiser_id):
    shard = get_shard(advertiser_id)
    db = connect_to_shard(shard)
    return db.select('campaigns', campaign_id)
```

**Problems with Manual Sharding:**
- Cross-shard transactions impossible
- Application complexity increased
- Rebalancing required downtime
- No ACID guarantees across shards

---

## 📖 Module 2: Understanding ACID in Distributed Systems

### **2.1 ACID Refresher**

#### **Atomicity**
```sql
-- Example: Transfer money between accounts
BEGIN TRANSACTION;
UPDATE accounts SET balance = balance - 100 WHERE id = 1;
UPDATE accounts SET balance = balance + 100 WHERE id = 2;
COMMIT; -- Both updates succeed or both fail
```

#### **Consistency**
```sql
-- Database constraints ensure valid state
ALTER TABLE accounts ADD CONSTRAINT positive_balance 
CHECK (balance >= 0);

-- This transaction would be rejected
UPDATE accounts SET balance = -50 WHERE id = 1; -- FAILS
```

#### **Isolation**
```sql
-- Two concurrent transactions don't interfere
-- Transaction 1
BEGIN;
SELECT balance FROM accounts WHERE id = 1; -- Returns 100
UPDATE accounts SET balance = 150 WHERE id = 1;
COMMIT;

-- Transaction 2 (concurrent)
BEGIN;
SELECT balance FROM accounts WHERE id = 1; -- Still sees 100 until T1 commits
UPDATE accounts SET balance = 200 WHERE id = 1;
COMMIT;
```

#### **Durability**
```sql
-- Once committed, data survives system crashes
COMMIT; -- Data is now guaranteed to be persistent
-- Even if power fails immediately after, data is safe
```

### **2.2 Distributed Systems Challenges**

#### **The CAP Theorem**
```
CAP Theorem: You can have at most 2 of 3:
- Consistency: All nodes see same data
- Availability: System remains operational
- Partition Tolerance: Works despite network failures

Google's Choice: Consistency + Partition Tolerance
(Sacrifice some availability for strong consistency)
```

#### **Network Partitions**
```
Scenario: Network split between data centers
Data Center A: Has users 1-1000
Data Center B: Has users 1001-2000

Problem: User 500 in DC-A wants to transfer money to User 1500 in DC-B
Network partition prevents communication between DCs

Traditional Solution: Choose consistency (reject transaction) or availability (allow inconsistent state)
Spanner Solution: Wait for partition to heal, maintain strong consistency
```

---

## 📖 Module 3: Google Spanner Architecture Deep Dive

### **3.1 High-Level Architecture**
```
Global Spanner Deployment:
┌─────────────────────────────────────────────────────────┐
│                 Global Spanner Network                 │
├─────────────┬─────────────┬─────────────┬─────────────┤
│   Region 1  │   Region 2  │   Region 3  │   Region N  │
│ (US-East)   │ (US-West)   │ (Europe)    │   (Asia)    │
├─────────────┼─────────────┼─────────────┼─────────────┤
│  Zone A     │  Zone A     │  Zone A     │  Zone A     │
│  Zone B     │  Zone B     │  Zone B     │  Zone B     │
│  Zone C     │  Zone C     │  Zone C     │  Zone C     │
└─────────────┴─────────────┴─────────────┴─────────────┘
```

### **3.2 Spanner Components**

#### **Spanserver**
```
Each Spanserver manages:
- 100-1000 tablets (data partitions)
- Paxos state machines for each tablet
- Lock table for concurrency control
- Transaction manager for 2PC
```

#### **Zone Master**
```python
class ZoneManager:
    def __init__(self):
        self.spanservers = []
        self.placement_driver = PlacementDriver()
    
    def assign_tablets(self, tablets):
        """Distribute tablets across spanservers"""
        for tablet in tablets:
            best_server = self.find_best_server(tablet)
            best_server.assign_tablet(tablet)
    
    def handle_failures(self, failed_server):
        """Reassign tablets from failed server"""
        tablets = failed_server.get_tablets()
        self.reassign_tablets(tablets)
```

#### **Universe Master**
```python
class UniverseMaster:
    def __init__(self):
        self.zone_masters = {}
        self.global_metadata = {}
    
    def create_database(self, db_name, schema):
        """Create globally distributed database"""
        for zone in self.zone_masters:
            zone.create_database_partition(db_name, schema)
    
    def get_tablet_location(self, key):
        """Find which zone/server contains data for key"""
        return self.placement_driver.locate_tablet(key)
```

### **3.3 Data Distribution**

#### **Automatic Sharding**
```sql
-- Spanner automatically partitions tables
CREATE TABLE campaigns (
    advertiser_id INT64,
    campaign_id INT64,
    name STRING(255),
    budget NUMERIC,
    PRIMARY KEY (advertiser_id, campaign_id)
) PRIMARY KEY (advertiser_id), -- Partition by advertiser_id
  INTERLEAVE IN PARENT advertisers ON DELETE CASCADE;
```

#### **Tablet Management**
```python
class Tablet:
    def __init__(self, start_key, end_key):
        self.start_key = start_key
        self.end_key = end_key
        self.replicas = []  # Paxos group
        self.leader = None
    
    def split_tablet(self, split_key):
        """Split tablet when it gets too large"""
        left_tablet = Tablet(self.start_key, split_key)
        right_tablet = Tablet(split_key, self.end_key)
        return left_tablet, right_tablet
    
    def move_tablet(self, new_spanserver):
        """Move tablet to different server for load balancing"""
        self.replicas.append(new_spanserver)
        # Gradually shift traffic to new location
        # Remove old replicas once migration complete
```

---

## 📖 Module 4: Implementing Atomicity with Two-Phase Commit

### **4.1 Two-Phase Commit Protocol**

#### **Phase 1: Prepare**
```python
class TransactionCoordinator:
    def __init__(self):
        self.participants = []
        self.transaction_id = None
    
    def prepare_phase(self, transaction):
        """Ask all participants if they can commit"""
        self.transaction_id = generate_transaction_id()
        votes = []
        
        for participant in self.participants:
            try:
                vote = participant.prepare(self.transaction_id, transaction)
                votes.append(vote)
            except Exception as e:
                votes.append("ABORT")
        
        return all(vote == "YES" for vote in votes)
```

#### **Phase 2: Commit**
```python
    def commit_phase(self, can_commit):
        """Tell all participants to commit or abort"""
        if can_commit:
            # All participants voted YES
            for participant in self.participants:
                try:
                    participant.commit(self.transaction_id)
                except Exception as e:
                    # Handle commit failures
                    self.handle_commit_failure(participant, e)
        else:
            # At least one participant voted NO
            for participant in self.participants:
                participant.abort(self.transaction_id)
```

#### **Participant Implementation**
```python
class SpannerParticipant:
    def __init__(self):
        self.prepared_transactions = {}
        self.lock_manager = LockManager()
    
    def prepare(self, transaction_id, operations):
        """Prepare to commit transaction"""
        try:
            # Acquire all necessary locks
            locks = self.acquire_locks(operations)
            
            # Validate operations can be performed
            if self.can_perform_operations(operations):
                # Hold locks and transaction state
                self.prepared_transactions[transaction_id] = {
                    'operations': operations,
                    'locks': locks,
                    'prepared_at': current_time()
                }
                return "YES"
            else:
                self.release_locks(locks)
                return "NO"
        except Exception:
            return "NO"
    
    def commit(self, transaction_id):
        """Actually perform the transaction"""
        if transaction_id in self.prepared_transactions:
            tx_data = self.prepared_transactions[transaction_id]
            
            # Perform all operations atomically
            self.execute_operations(tx_data['operations'])
            
            # Release locks
            self.release_locks(tx_data['locks'])
            
            # Clean up
            del self.prepared_transactions[transaction_id]
```

### **4.2 Handling 2PC Failures**

#### **Coordinator Failure Recovery**
```python
class TransactionRecovery:
    def recover_coordinator_failure(self, failed_coordinator_id):
        """Recover when coordinator crashes"""
        # Read transaction log to find incomplete transactions
        incomplete_txns = self.read_transaction_log(failed_coordinator_id)
        
        for txn in incomplete_txns:
            if txn.phase == "PREPARE_SENT":
                # Query participants for their votes
                votes = self.query_participant_votes(txn.id)
                if all(vote == "YES" for vote in votes):
                    self.send_commit(txn.id)
                else:
                    self.send_abort(txn.id)
            elif txn.phase == "COMMIT_SENT":
                # Ensure all participants committed
                self.ensure_commit_completion(txn.id)
```

#### **Participant Timeout Handling**
```python
    def handle_coordinator_timeout(self, transaction_id):
        """Handle when coordinator doesn't respond"""
        # Contact other participants to determine transaction outcome
        other_participants = self.get_other_participants(transaction_id)
        
        for participant in other_participants:
            status = participant.get_transaction_status(transaction_id)
            if status == "COMMITTED":
                self.commit(transaction_id)
                return
            elif status == "ABORTED":
                self.abort(transaction_id)
                return
        
        # If uncertain, must wait for coordinator recovery
        # Cannot unilaterally decide without risking inconsistency
        self.wait_for_coordinator_recovery(transaction_id)
```

---

## 📖 Module 5: Global Consistency with TrueTime

### **5.1 The Time Synchronization Problem**

#### **Why Timestamps Matter**
```python
# Without synchronized clocks, this can happen:
# Server A (clock: 10:00:01): User updates profile
# Server B (clock: 10:00:00): User reads profile (sees old data!)

# The read happened after the write in real time,
# but server clocks made it appear to happen before
```

#### **Traditional Solutions and Their Problems**
```python
# Network Time Protocol (NTP)
class NTPClient:
    def sync_time(self):
        # Typical NTP accuracy: ±1-50ms
        # Not accurate enough for global consistency
        server_time = self.query_ntp_server()
        local_offset = server_time - local_time()
        self.adjust_clock(local_offset)

# Logical Clocks (Lamport Timestamps)
class LamportClock:
    def __init__(self):
        self.counter = 0
    
    def tick(self):
        self.counter += 1
        return self.counter
    
    def update(self, received_timestamp):
        self.counter = max(self.counter, received_timestamp) + 1
        return self.counter

# Problem: Doesn't correspond to real time
```

### **5.2 TrueTime Architecture**

#### **TrueTime Components**
```python
class TrueTimeServer:
    def __init__(self):
        self.gps_receivers = [GPSReceiver() for _ in range(4)]
        self.atomic_clocks = [AtomicClock() for _ in range(2)]
        self.network_time_servers = [NTPServer() for _ in range(10)]
    
    def get_current_time(self):
        """Get current time with uncertainty bounds"""
        # Collect time from all sources
        gps_times = [gps.get_time() for gps in self.gps_receivers]
        atomic_times = [clock.get_time() for clock in self.atomic_clocks]
        ntp_times = [ntp.get_time() for ntp in self.network_time_servers]
        
        # Calculate best estimate and uncertainty
        best_estimate = self.calculate_consensus_time(
            gps_times + atomic_times + ntp_times
        )
        uncertainty = self.calculate_uncertainty(
            gps_times, atomic_times, ntp_times
        )
        
        return TrueTimeInterval(
            earliest=best_estimate - uncertainty,
            latest=best_estimate + uncertainty
        )
```

#### **TrueTime API**
```python
class TrueTimeInterval:
    def __init__(self, earliest, latest):
        self.earliest = earliest  # Earliest possible current time
        self.latest = latest      # Latest possible current time
    
    def now(self):
        """Get current time interval"""
        return TrueTime.get_current_time()
    
    def after(self, timestamp):
        """Check if current time is definitely after timestamp"""
        current = self.now()
        return current.earliest > timestamp
    
    def before(self, timestamp):
        """Check if current time is definitely before timestamp"""
        current = self.now()
        return current.latest < timestamp
```

### **5.3 Using TrueTime for Consistency**

#### **Write Operations with TrueTime**
```python
class SpannerWrite:
    def write_with_timestamp(self, data, key):
        """Write data with TrueTime timestamp"""
        # Get current TrueTime
        tt_now = TrueTime.now()
        
        # Choose commit timestamp
        commit_timestamp = tt_now.latest
        
        # Wait until we're sure this timestamp has passed
        while not TrueTime.after(commit_timestamp):
            time.sleep(0.001)  # Wait 1ms
        
        # Now safe to commit with this timestamp
        self.commit_write(key, data, commit_timestamp)
        return commit_timestamp
```

#### **Read Operations with TrueTime**
```python
class SpannerRead:
    def read_with_consistency(self, key, read_timestamp=None):
        """Read data with strong consistency"""
        if read_timestamp is None:
            # Use current TrueTime for read
            read_timestamp = TrueTime.now().latest
        
        # Find replica with data at or after read_timestamp
        replica = self.find_up_to_date_replica(key, read_timestamp)
        
        # If no replica is up-to-date, wait
        if replica is None:
            self.wait_for_replica_catchup(key, read_timestamp)
            replica = self.find_up_to_date_replica(key, read_timestamp)
        
        return replica.read(key, read_timestamp)
    
    def find_up_to_date_replica(self, key, timestamp):
        """Find replica with data at least as recent as timestamp"""
        for replica in self.get_replicas(key):
            if replica.last_update_timestamp >= timestamp:
                return replica
        return None
```

#### **Cross-Datacenter Consistency**
```python
class GlobalConsistencyManager:
    def ensure_global_consistency(self, write_timestamp):
        """Ensure write is visible globally before returning"""
        # Get list of all datacenters
        datacenters = self.get_all_datacenters()
        
        for datacenter in datacenters:
            # Wait until datacenter's TrueTime passes write timestamp
            while not datacenter.truetime_after(write_timestamp):
                time.sleep(0.001)
        
        # Now safe to return - write is globally visible
        return True
```

---

## 📖 Module 6: Isolation with Locking and MVCC

### **6.1 Two-Phase Locking for Writes**

#### **Lock Manager Implementation**
```python
class SpannerLockManager:
    def __init__(self):
        self.locks = {}  # key -> Lock object
        self.wait_queue = defaultdict(list)
    
    def acquire_lock(self, transaction_id, key, lock_type):
        """Acquire lock on key for transaction"""
        if key not in self.locks:
            # No existing lock, grant immediately
            self.locks[key] = Lock(transaction_id, lock_type)
            return True
        
        existing_lock = self.locks[key]
        
        if existing_lock.is_compatible(lock_type):
            # Compatible lock types can coexist
            existing_lock.add_holder(transaction_id, lock_type)
            return True
        else:
            # Incompatible, add to wait queue
            self.wait_queue[key].append((transaction_id, lock_type))
            return False
    
    def release_lock(self, transaction_id, key):
        """Release lock held by transaction"""
        if key in self.locks:
            self.locks[key].remove_holder(transaction_id)
            
            if self.locks[key].is_empty():
                del self.locks[key]
                self.process_wait_queue(key)

class Lock:
    def __init__(self, transaction_id, lock_type):
        self.holders = {transaction_id: lock_type}
    
    def is_compatible(self, new_lock_type):
        """Check if new lock type is compatible with existing"""
        for existing_type in self.holders.values():
            if not self.compatible(existing_type, new_lock_type):
                return False
        return True
    
    def compatible(self, lock1, lock2):
        """Define lock compatibility matrix"""
        compatibility = {
            ('READ', 'READ'): True,
            ('READ', 'WRITE'): False,
            ('WRITE', 'READ'): False,
            ('WRITE', 'WRITE'): False
        }
        return compatibility.get((lock1, lock2), False)
```

#### **Two-Phase Locking Protocol**
```python
class TwoPhaseLocking:
    def __init__(self):
        self.lock_manager = SpannerLockManager()
        self.transaction_locks = defaultdict(set)
        self.phase = {}  # transaction_id -> 'GROWING' or 'SHRINKING'
    
    def begin_transaction(self, transaction_id):
        """Start new transaction in growing phase"""
        self.phase[transaction_id] = 'GROWING'
        self.transaction_locks[transaction_id] = set()
    
    def acquire_lock(self, transaction_id, key, lock_type):
        """Acquire lock during growing phase"""
        if self.phase[transaction_id] != 'GROWING':
            raise Exception("Cannot acquire lock in shrinking phase")
        
        if self.lock_manager.acquire_lock(transaction_id, key, lock_type):
            self.transaction_locks[transaction_id].add(key)
            return True
        return False
    
    def begin_shrinking_phase(self, transaction_id):
        """Enter shrinking phase - start releasing locks"""
        self.phase[transaction_id] = 'SHRINKING'
    
    def release_all_locks(self, transaction_id):
        """Release all locks held by transaction"""
        for key in self.transaction_locks[transaction_id]:
            self.lock_manager.release_lock(transaction_id, key)
        
        del self.transaction_locks[transaction_id]
        del self.phase[transaction_id]
```

### **6.2 Snapshot Isolation for Reads**

#### **Multi-Version Storage**
```python
class MultiVersionStorage:
    def __init__(self):
        self.versions = defaultdict(list)  # key -> list of (timestamp, value)
    
    def write(self, key, value, timestamp):
        """Write new version of data"""
        # Insert in timestamp order
        versions = self.versions[key]
        insert_pos = self.find_insert_position(versions, timestamp)
        versions.insert(insert_pos, (timestamp, value))
        
        # Garbage collect old versions
        self.garbage_collect_versions(key)
    
    def read(self, key, read_timestamp):
        """Read data as of specific timestamp"""
        versions = self.versions[key]
        
        # Find latest version <= read_timestamp
        for timestamp, value in reversed(versions):
            if timestamp <= read_timestamp:
                return value
        
        # No version found
        return None
    
    def find_insert_position(self, versions, timestamp):
        """Binary search to find insertion point"""
        left, right = 0, len(versions)
        while left < right:
            mid = (left + right) // 2
            if versions[mid][0] < timestamp:
                left = mid + 1
            else:
                right = mid
        return left
    
    def garbage_collect_versions(self, key, keep_versions=10):
        """Remove old versions to save space"""
        versions = self.versions[key]
        if len(versions) > keep_versions:
            # Keep only most recent versions
            self.versions[key] = versions[-keep_versions:]
```

#### **Snapshot Transaction Implementation**
```python
class SnapshotTransaction:
    def __init__(self, transaction_id, start_timestamp):
        self.transaction_id = transaction_id
        self.start_timestamp = start_timestamp
        self.reads = {}  # Cache reads for consistency
    
    def read(self, key):
        """Read data as of transaction start time"""
        if key in self.reads:
            # Return cached read for consistency
            return self.reads[key]
        
        # Read from multi-version storage
        value = self.storage.read(key, self.start_timestamp)
        self.reads[key] = value
        return value
    
    def write(self, key, value):
        """Buffer writes until commit"""
        if not hasattr(self, 'writes'):
            self.writes = {}
        self.writes[key] = value
    
    def commit(self):
        """Commit all writes with new timestamp"""
        if not hasattr(self, 'writes'):
            return  # Read-only transaction
        
        # Get commit timestamp
        commit_timestamp = TrueTime.now().latest
        
        # Check for write-write conflicts
        for key in self.writes:
            if self.has_write_conflict(key, commit_timestamp):
                raise WriteConflictException(f"Write conflict on key {key}")
        
        # Apply all writes atomically
        for key, value in self.writes.items():
            self.storage.write(key, value, commit_timestamp)
    
    def has_write_conflict(self, key, commit_timestamp):
        """Check if another transaction wrote to key after our start"""
        latest_write = self.storage.get_latest_write_timestamp(key)
        return latest_write > self.start_timestamp
```

---

## 📖 Module 7: Durability with Paxos Replication

### **7.1 Paxos Consensus Algorithm**

#### **Paxos Roles**
```python
class PaxosParticipant:
    def __init__(self, node_id):
        self.node_id = node_id
        self.promised_ballot = None
        self.accepted_ballot = None
        self.accepted_value = None

class PaxosProposer:
    def __init__(self, node_id):
        self.node_id = node_id
        self.ballot_number = 0
    
    def propose_value(self, value, acceptors):
        """Propose a value using Paxos protocol"""
        # Phase 1: Prepare
        self.ballot_number += 1
        ballot = (self.ballot_number, self.node_id)
        
        promises = self.send_prepare(ballot, acceptors)
        if len(promises) <= len(acceptors) // 2:
            return False  # Not enough promises
        
        # Choose value (either proposed or highest from promises)
        chosen_value = self.choose_value(value, promises)
        
        # Phase 2: Accept
        accepts = self.send_accept(ballot, chosen_value, acceptors)
        return len(accepts) > len(acceptors) // 2
    
    def send_prepare(self, ballot, acceptors):
        """Send prepare messages to acceptors"""
        promises = []
        for acceptor in acceptors:
            promise = acceptor.prepare(ballot)
            if promise:
                promises.append(promise)
        return promises
    
    def send_accept(self, ballot, value, acceptors):
        """Send accept messages to acceptors"""
        accepts = []
        for acceptor in acceptors:
            if acceptor.accept(ballot, value):
                accepts.append(acceptor.node_id)
        return accepts
```

#### **Paxos Acceptor**
```python
class PaxosAcceptor:
    def __init__(self, node_id):
        self.node_id = node_id
        self.promised_ballot = None
        self.accepted_ballot = None
        self.accepted_value = None
    
    def prepare(self, ballot):
        """Handle prepare message"""
        if self.promised_ballot is None or ballot > self.promised_ballot:
            # Promise not to accept lower-numbered ballots
            self.promised_ballot = ballot
            
            # Return promise with any previously accepted value
            return {
                'node_id': self.node_id,
                'ballot': self.accepted_ballot,
                'value': self.accepted_value
            }
        return None  # Reject
    
    def accept(self, ballot, value):
        """Handle accept message"""
        if self.promised_ballot is None or ballot >= self.promised_ballot:
            # Accept the proposal
            self.promised_ballot = ballot
            self.accepted_ballot = ballot
            self.accepted_value = value
            return True
        return False  # Reject
```

### **7.2 Spanner's Use of Paxos**

#### **Paxos Group per Tablet**
```python
class SpannerTablet:
    def __init__(self, tablet_id, replicas):
        self.tablet_id = tablet_id
        self.replicas = replicas
        self.paxos_group = PaxosGroup(replicas)
        self.leader = None
        self.state_machine = TabletStateMachine()
    
    def write(self, key, value, timestamp):
        """Write data using Paxos consensus"""
        if not self.is_leader():
            raise NotLeaderException("Only leader can initiate writes")
        
        # Create log entry
        log_entry = LogEntry(
            operation='WRITE',
            key=key,
            value=value,
            timestamp=timestamp
        )
        
        # Use Paxos to replicate log entry
        if self.paxos_group.propose(log_entry):
            # Apply to state machine once committed
            self.state_machine.apply(log_entry)
            return True
        return False
    
    def read(self, key, timestamp):
        """Read data (can be from any replica)"""
        # For reads, we can serve from any up-to-date replica
        if self.state_machine.is_up_to_date(timestamp):
            return self.state_machine.read(key, timestamp)
        else:
            # Forward to leader or wait for catch-up
            return self.forward_read_to_leader(key, timestamp)
```

#### **Leader Election with Paxos**
```python
class PaxosLeaderElection:
    def __init__(self, node_id, paxos_group):
        self.node_id = node_id
        self.paxos_group = paxos_group
        self.lease_duration = 30  # 30 seconds
    
    def become_leader(self):
        """Try to become leader using Paxos"""
        lease_proposal = LeaderLease(
            leader=self.node_id,
            start_time=TrueTime.now().latest,
            duration=self.lease_duration
        )
        
        # Use Paxos to agree on leader lease
        if self.paxos_group.propose(lease_proposal):
            self.current_lease = lease_proposal
            self.start_leader_duties()
            return True
        return False
    
    def renew_lease(self):
        """Renew leadership lease before expiration"""
        if self.is_leader() and self.lease_expiring_soon():
            new_lease = LeaderLease(
                leader=self.node_id,
                start_time=TrueTime.now().latest,
                duration=self.lease_duration
            )
            return self.paxos_group.propose(new_lease)
        return False
    
    def is_leader(self):
        """Check if this node is currently the leader"""
        if not hasattr(self, 'current_lease'):
            return False
        
        return (self.current_lease.leader == self.node_id and
                not self.current_lease.is_expired())
```

### **7.3 Write-Ahead Logging**

#### **Durable Log Implementation**
```python
class WriteAheadLog:
    def __init__(self, log_file_path):
        self.log_file = open(log_file_path, 'a+b')
        self.log_index = self.read_log_index()
    
    def append_entry(self, entry):
        """Append entry to log and force to disk"""
        # Serialize entry
        serialized = self.serialize_entry(entry)
        
        # Write to log file
        self.log_file.write(serialized)
        self.log_file.flush()
        os.fsync(self.log_file.fileno())  # Force to disk
        
        # Update index
        self.log_index += 1
        return self.log_index
    
    def read_entries(self, start_index, end_index=None):
        """Read entries from log for recovery"""
        entries = []
        self.log_file.seek(0)
        
        current_index = 0
        while True:
            try:
                entry = self.deserialize_entry(self.log_file)
                if current_index >= start_index:
                    entries.append(entry)
                    if end_index and current_index >= end_index:
                        break
                current_index += 1
            except EOFError:
                break
        
        return entries
    
    def checkpoint(self, state_machine_snapshot):
        """Create checkpoint to truncate log"""
        checkpoint_file = f"{self.log_file.name}.checkpoint"
        with open(checkpoint_file, 'wb') as f:
            f.write(state_machine_snapshot)
        
        # Truncate log after checkpoint
        self.log_file.seek(0)
        self.log_file.truncate()
        self.log_index = 0
```

#### **Recovery Process**
```python
class SpannerRecovery:
    def recover_tablet(self, tablet_id):
        """Recover tablet state after crash"""
        # Load last checkpoint
        state_machine = self.load_checkpoint(tablet_id)
        checkpoint_index = state_machine.last_applied_index
        
        # Replay log entries since checkpoint
        wal = WriteAheadLog(f"/data/tablet_{tablet_id}.log")
        log_entries = wal.read_entries(checkpoint_index + 1)
        
        for entry in log_entries:
            if entry.is_committed():
                state_machine.apply(entry)
        
        # Rejoin Paxos group
        paxos_group = self.rejoin_paxos_group(tablet_id)
        
        # Catch up any missing entries
        self.catch_up_with_group(state_machine, paxos_group)
        
        return SpannerTablet(tablet_id, state_machine, paxos_group)
    
    def catch_up_with_group(self, state_machine, paxos_group):
        """Sync with other replicas to catch up"""
        my_last_index = state_machine.last_applied_index
        
        for replica in paxos_group.replicas:
            replica_last_index = replica.get_last_applied_index()
            if replica_last_index > my_last_index:
                # Request missing entries
                missing_entries = replica.get_entries(
                    my_last_index + 1, replica_last_index
                )
                for entry in missing_entries:
                    if entry.is_committed():
                        state_machine.apply(entry)
```

---

## 📖 Module 8: Practical Implementation Exercises

### **8.1 Building a Simplified Spanner**

#### **Exercise 1: Implement TrueTime Simulation**
```python
import time
import random
from dataclasses import dataclass

@dataclass
class TrueTimeInterval:
    earliest: float
    latest: float
    
    def now(self):
        # Simulate uncertainty in time measurement
        uncertainty = random.uniform(0.001, 0.010)  # 1-10ms uncertainty
        current_time = time.time()
        return TrueTimeInterval(
            earliest=current_time - uncertainty,
            latest=current_time + uncertainty
        )
    
    def after(self, timestamp):
        return self.earliest > timestamp
    
    def before(self, timestamp):
        return self.latest < timestamp

# TODO: Implement this class
class SimpleTrueTime:
    def __init__(self):
        pass
    
    def now(self):
        # Your implementation here
        pass
    
    def wait_until_after(self, timestamp):
        # Your implementation here
        pass

# Test your implementation
truetime = SimpleTrueTime()
t1 = truetime.now()
time.sleep(0.01)
t2 = truetime.now()
print(f"T1: {t1.earliest}-{t1.latest}")
print(f"T2: {t2.earliest}-{t2.latest}")
print(f"T2 after T1: {t2.after(t1.latest)}")
```

#### **Exercise 2: Implement Two-Phase Commit**
```python
from enum import Enum
from typing import List, Dict

class TransactionStatus(Enum):
    PREPARING = "preparing"
    COMMITTED = "committed"
    ABORTED = "aborted"

class TwoPhaseCommitCoordinator:
    def __init__(self):
        self.participants: List[Participant] = []
        self.transaction_log: Dict[str, TransactionStatus] = {}
    
    def add_participant(self, participant):
        self.participants.append(participant)
    
    def commit_transaction(self, transaction_id, operations):
        """
        TODO: Implement two-phase commit protocol
        
        Phase 1:
        1. Send PREPARE message to all participants
        2. Wait for votes from all participants
        3. If all vote YES, proceed to phase 2
        4. If any vote NO, send ABORT to all
        
        Phase 2:
        1. Send COMMIT to all participants if all voted YES
        2. Send ABORT to all participants if any voted NO
        3. Wait for acknowledgments
        
        Return: True if committed, False if aborted
        """
        pass

class Participant:
    def __init__(self, participant_id):
        self.participant_id = participant_id
        self.prepared_transactions = {}
    
    def prepare(self, transaction_id, operations):
        """
        TODO: Implement prepare phase
        
        1. Check if operations can be performed
        2. Lock necessary resources
        3. Return YES if can commit, NO otherwise
        """
        pass
    
    def commit(self, transaction_id):
        """
        TODO: Implement commit phase
        
        1. Perform the prepared operations
        2. Release locks
        3. Return acknowledgment
        """
        pass
    
    def abort(self, transaction_id):
        """
        TODO: Implement abort phase
        
        1. Discard prepared operations
        2. Release locks
        3. Return acknowledgment
        """
        pass

# Test your implementation
coordinator = TwoPhaseCommitCoordinator()
participant1 = Participant("p1")
participant2 = Participant("p2")

coordinator.add_participant(participant1)
coordinator.add_participant(participant2)

# Test successful commit
result = coordinator.commit_transaction("tx1", ["update account_1", "update account_2"])
print(f"Transaction result: {result}")
```

#### **Exercise 3: Implement Snapshot Isolation**
```python
from collections import defaultdict
import bisect

class Version:
    def __init__(self, timestamp, value):
        self.timestamp = timestamp
        self.value = value

class MultiVersionDatabase:
    def __init__(self):
        self.data = defaultdict(list)  # key -> list of Version objects
    
    def write(self, key, value, timestamp):
        """
        TODO: Implement write operation
        
        1. Create new version with timestamp
        2. Insert in timestamp order
        3. Clean up old versions if needed
        """
        pass
    
    def read(self, key, read_timestamp):
        """
        TODO: Implement read operation
        
        1. Find latest version with timestamp <= read_timestamp
        2. Return the value
        3. Return None if no such version exists
        """
        pass
    
    def garbage_collect(self, key, keep_count=5):
        """
        TODO: Remove old versions to save space
        
        Keep only the most recent 'keep_count' versions
        """
        pass

class SnapshotTransaction:
    def __init__(self, database, start_timestamp):
        self.database = database
        self.start_timestamp = start_timestamp
        self.read_cache = {}
        self.write_buffer = {}
    
    def read(self, key):
        """
        TODO: Implement snapshot read
        
        1. Check read cache first
        2. Read from database at start_timestamp
        3. Cache the result
        """
        pass
    
    def write(self, key, value):
        """
        TODO: Buffer write operations
        
        Store writes in buffer until commit
        """
        pass
    
    def commit(self, commit_timestamp):
        """
        TODO: Commit all buffered writes
        
        1. Check for write conflicts
        2. Apply all writes atomically
        3. Clear write buffer
        """
        pass

# Test your implementation
db = MultiVersionDatabase()
db.write("key1", "value1", 1.0)
db.write("key1", "value2", 2.0)
db.write("key1", "value3", 3.0)

# Read at different timestamps
print(f"Read at t=1.5: {db.read('key1', 1.5)}")  # Should return "value1"
print(f"Read at t=2.5: {db.read('key1', 2.5)}")  # Should return "value2"
print(f"Read at t=3.5: {db.read('key1', 3.5)}")  # Should return "value3"
```

### **8.2 Performance Testing**

#### **Latency Measurement**
```python
import time
import statistics
from concurrent.futures import ThreadPoolExecutor, as_completed

def measure_operation_latency(operation_func, num_operations=1000):
    """Measure latency of operations"""
    latencies = []
    
    for _ in range(num_operations):
        start_time = time.perf_counter()
        operation_func()
        end_time = time.perf_counter()
        latencies.append((end_time - start_time) * 1000)  # Convert to ms
    
    return {
        'mean': statistics.mean(latencies),
        'median': statistics.median(latencies),
        'p95': statistics.quantiles(latencies, n=20)[18],  # 95th percentile
        'p99': statistics.quantiles(latencies, n=100)[98],  # 99th percentile
        'max': max(latencies)
    }

def test_concurrent_operations(operation_func, num_threads=10, ops_per_thread=100):
    """Test concurrent operations"""
    start_time = time.time()
    
    with ThreadPoolExecutor(max_workers=num_threads) as executor:
        futures = []
        for _ in range(num_threads):
            for _ in range(ops_per_thread):
                future = executor.submit(operation_func)
                futures.append(future)
        
        # Wait for all operations to complete
        for future in as_completed(futures):
            future.result()
    
    end_time = time.time()
    total_ops = num_threads * ops_per_thread
    throughput = total_ops / (end_time - start_time)
    
    return {
        'total_operations': total_ops,
        'duration': end_time - start_time,
        'throughput': throughput
    }

# Example usage
def sample_read_operation():
    # Simulate database read
    time.sleep(0.001)  # 1ms simulated latency
    return "data"

def sample_write_operation():
    # Simulate database write
    time.sleep(0.005)  # 5ms simulated latency
    return True

# Measure performance
read_latency = measure_operation_latency(sample_read_operation)
print(f"Read latency: {read_latency}")

write_throughput = test_concurrent_operations(sample_write_operation)
print(f"Write throughput: {write_throughput}")
```

---

## 📖 Module 9: Real-World Application

### **9.1 Case Study: Building an Ad Auction System**

#### **Requirements**
```python
"""
Ad Auction System Requirements:
1. Support 1M+ auctions per second globally
2. Strong consistency for advertiser budgets
3. Real-time bid processing (<100ms)
4. Accurate billing and budget tracking
5. Global deployment across regions
"""

class AdAuctionSystem:
    def __init__(self):
        self.spanner_db = SpannerDatabase()
        self.auction_service = AuctionService(self.spanner_db)
        self.billing_service = BillingService(self.spanner_db)
    
    def process_ad_request(self, request):
        """
        TODO: Implement ad auction process
        
        1. Find eligible ads for the request
        2. Run auction algorithm
        3. Update budgets atomically
        4. Return winning ad
        """
        pass
```

#### **Schema Design**
```sql
-- Spanner schema for ad auction system
CREATE TABLE advertisers (
    advertiser_id INT64,
    name STRING(255),
    total_budget NUMERIC,
    daily_budget NUMERIC,
    status STRING(20),
    PRIMARY KEY (advertiser_id)
);

CREATE TABLE campaigns (
    advertiser_id INT64,
    campaign_id INT64,
    name STRING(255),
    budget NUMERIC,
    daily_budget NUMERIC,
    target_keywords ARRAY<STRING(100)>,
    status STRING(20),
    PRIMARY KEY (advertiser_id, campaign_id)
) INTERLEAVE IN PARENT advertisers ON DELETE CASCADE;

CREATE TABLE ads (
    advertiser_id INT64,
    campaign_id INT64,
    ad_id INT64,
    title STRING(100),
    description STRING(500),
    landing_url STRING(1000),
    bid_amount NUMERIC,
    status STRING(20),
    PRIMARY KEY (advertiser_id, campaign_id, ad_id)
) INTERLEAVE IN PARENT campaigns ON DELETE CASCADE;

CREATE TABLE budget_tracking (
    advertiser_id INT64,
    date DATE,
    spent_amount NUMERIC,
    impression_count INT64,
    click_count INT64,
    PRIMARY KEY (advertiser_id, date)
);
```

### **9.2 Implementation Challenges**

#### **Challenge 1: Budget Consistency**
```python
class BudgetManager:
    def __init__(self, spanner_db):
        self.db = spanner_db
    
    def check_and_deduct_budget(self, advertiser_id, amount):
        """
        Atomically check budget and deduct amount
        Must be strongly consistent to prevent overspend
        """
        with self.db.transaction() as txn:
            # Read current budget
            budget_row = txn.read(
                'advertisers',
                keys=[advertiser_id],
                columns=['daily_budget', 'spent_today']
            )[0]
            
            current_budget = budget_row['daily_budget']
            spent_today = budget_row['spent_today']
            remaining = current_budget - spent_today
            
            if remaining >= amount:
                # Sufficient budget, deduct amount
                txn.update(
                    'advertisers',
                    [advertiser_id],
                    {'spent_today': spent_today + amount}
                )
                return True
            else:
                # Insufficient budget
                return False
```

#### **Challenge 2: Global Latency**
```python
class GlobalAuctionService:
    def __init__(self):
        self.regional_services = {
            'us-east': AuctionService('us-east-spanner'),
            'us-west': AuctionService('us-west-spanner'),
            'europe': AuctionService('europe-spanner'),
            'asia': AuctionService('asia-spanner')
        }
    
    def process_request(self, ad_request):
        """Route request to nearest region"""
        region = self.determine_region(ad_request.ip_address)
        service = self.regional_services[region]
        return service.run_auction(ad_request)
    
    def replicate_budget_updates(self, advertiser_id, amount):
        """Replicate budget changes to all regions"""
        # Use Spanner's global transactions for consistency
        with self.global_transaction() as txn:
            for region in self.regional_services:
                txn.update_budget(region, advertiser_id, amount)
```

---

## 📖 Module 10: Advanced Topics and Optimizations

### **10.1 Schema Design Best Practices**

#### **Interleaved Tables**
```sql
-- Parent table
CREATE TABLE customers (
    customer_id INT64,
    name STRING(255),
    email STRING(255),
    PRIMARY KEY (customer_id)
);

-- Child table interleaved with parent
CREATE TABLE orders (
    customer_id INT64,
    order_id INT64,
    order_date TIMESTAMP,
    total_amount NUMERIC,
    PRIMARY KEY (customer_id, order_id)
) INTERLEAVE IN PARENT customers ON DELETE CASCADE;

-- Grandchild table
CREATE TABLE order_items (
    customer_id INT64,
    order_id INT64,
    item_id INT64,
    product_id INT64,
    quantity INT64,
    price NUMERIC,
    PRIMARY KEY (customer_id, order_id, item_id)
) INTERLEAVE IN PARENT orders ON DELETE CASCADE;
```

**Benefits of Interleaving:**
- Related data stored together physically
- Improved performance for joins
- Better locality for transactions

#### **Secondary Indexes**
```sql
-- Create secondary index
CREATE INDEX idx_orders_by_date
ON orders (order_date)
STORING (total_amount);

-- Create null-filtered index
CREATE NULL_FILTERED INDEX idx_active_customers
ON customers (status)
WHERE status IS NOT NULL;
```

### **10.2 Query Optimization**

#### **Avoiding Hot Spots**
```sql
-- Bad: Sequential primary key creates hot spots
CREATE TABLE events (
    event_id INT64,  -- Auto-incrementing
    timestamp TIMESTAMP,
    data STRING(MAX),
    PRIMARY KEY (event_id)
);

-- Good: Distributed primary key
CREATE TABLE events (
    shard_id INT64,     -- Hash of user_id or random
    timestamp TIMESTAMP,
    event_id INT64,
    data STRING(MAX),
    PRIMARY KEY (shard_id, timestamp, event_id)
);
```

#### **Efficient Query Patterns**
```python
# Efficient: Use primary key or index
def get_customer_orders(customer_id):
    return spanner.execute_sql("""
        SELECT order_id, order_date, total_amount
        FROM orders
        WHERE customer_id = @customer_id
        ORDER BY order_date DESC
        LIMIT 10
    """, {"customer_id": customer_id})

# Inefficient: Full table scan
def get_expensive_orders():
    return spanner.execute_sql("""
        SELECT *
        FROM orders
        WHERE total_amount > 1000  -- No index on total_amount
    """)

# Better: Add index or restructure query
def get_expensive_orders_efficient():
    # First, create index: CREATE INDEX idx_orders_amount ON orders(total_amount)
    return spanner.execute_sql("""
        SELECT *
        FROM orders@{FORCE_INDEX=idx_orders_amount}
        WHERE total_amount > 1000
    """)
```

### **10.3 Monitoring and Debugging**

#### **Performance Monitoring**
```python
class SpannerMonitor:
    def __init__(self, spanner_client):
        self.client = spanner_client
        self.metrics = {}
    
    def monitor_query_performance(self, query, params=None):
        """Monitor query execution metrics"""
        start_time = time.time()
        
        # Execute with execution stats
        result = self.client.execute_sql(
            query, 
            params=params,
            query_mode=spanner.QueryMode.PROFILE
        )
        
        end_time = time.time()
        latency = (end_time - start_time) * 1000
        
        # Extract execution statistics
        stats = result.stats
        
        metrics = {
            'latency_ms': latency,
            'rows_returned': stats.row_count_exact,
            'cpu_time_ms': stats.query_stats.cpu_time.total_seconds() * 1000,
            'scanned_rows': stats.query_stats.scanned_rows_count,
            'optimizer_version': stats.query_stats.optimizer_version
        }
        
        self.log_metrics(query, metrics)
        return result
    
    def detect_hot_spots(self):
        """Detect hot spots in data distribution"""
        # Query to find hot partitions
        hot_spots = self.client.execute_sql("""
            SELECT
                split_point,
                row_count,
                cpu_usage_percent
            FROM INFORMATION_SCHEMA.SPANNER_STATISTICS.QUERY_STATS_TOP_10M
            WHERE cpu_usage_percent > 80
            ORDER BY cpu_usage_percent DESC
        """)
        
        return list(hot_spots)
```

---

## 🎯 Summary and Next Steps

### **Key Takeaways**

1. **Distributed SQL is Possible**: Spanner proves you can have SQL semantics at global scale
2. **Time is Critical**: TrueTime enables global consistency through synchronized clocks
3. **ACID at Scale**: Two-phase commit and Paxos enable ACID properties across data centers
4. **Trade-offs Matter**: Spanner chooses consistency over availability during partitions

### **Skills Developed**
- ✅ Understanding distributed database architecture
- ✅ Implementing consensus algorithms (Paxos)
- ✅ Designing for global consistency
- ✅ Managing transactions across multiple data centers
- ✅ Optimizing for both performance and correctness

### **Practice Projects**
1. **Build Mini-Spanner**: Implement core components (TrueTime simulation, 2PC, Paxos)
2. **Design Global E-commerce**: Apply Spanner concepts to online retail system
3. **Financial Trading System**: Implement with strict consistency requirements
4. **Multi-region Social Network**: Handle global user data with local performance

### **Further Reading**
- [Spanner: Google's Globally Distributed Database (Original Paper)](https://static.googleusercontent.com/media/research.google.com/en//archive/spanner-osdi2012.pdf)
- [F1: A Distributed SQL Database That Scales](https://static.googleusercontent.com/media/research.google.com/en//pubs/archive/41344.pdf)
- [Spanner, TrueTime, and the CAP Theorem](https://research.google/pubs/spanner-truetime-and-the-cap-theorem/)

### **Next Case Study Preview**
Next, we'll explore Meta's cache consistency system and learn how to achieve 99.99999999% cache accuracy at global scale! 🚀
