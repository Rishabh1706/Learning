# Low-Level Design: Jenkins Re-Architecture

## Detailed Component Design

### 1. Jenkins Master Configuration

#### Kubernetes Resources
```yaml
# StatefulSet for Jenkins Master
apiVersion: apps/v1
kind: StatefulSet
metadata:
  name: jenkins-master
  namespace: jenkins
spec:
  serviceName: jenkins
  replicas: 1
  selector:
    matchLabels:
      app: jenkins-master
  template:
    metadata:
      labels:
        app: jenkins-master
    spec:
      serviceAccountName: jenkins
      containers:
      - name: jenkins
        image: jenkins/jenkins:lts
        ports:
        - containerPort: 8080
        - containerPort: 50000
        env:
        - name: JAVA_OPTS
          value: "-Xmx2048m -Djenkins.install.runSetupWizard=false"
        volumeMounts:
        - name: jenkins-home
          mountPath: /var/jenkins_home
        - name: docker-sock
          mountPath: /var/run/docker.sock
        resources:
          requests:
            memory: "2Gi"
            cpu: "1000m"
          limits:
            memory: "4Gi"
            cpu: "2000m"
  volumeClaimTemplates:
  - metadata:
      name: jenkins-home
    spec:
      accessModes: ["ReadWriteOnce"]
      storageClassName: gp3
      resources:
        requests:
          storage: 50Gi
```

#### Jenkins Configuration as Code (JCasC)
```yaml
jenkins:
  systemMessage: "Jenkins configured automatically by Jenkins Configuration as Code"
  numExecutors: 0
  mode: NORMAL
  scmCheckoutRetryCount: 3
  
  clouds:
    - kubernetes:
        name: "kubernetes"
        serverUrl: "https://kubernetes.default.svc.cluster.local"
        namespace: "jenkins-agents"
        credentialsId: "k8s-service-account"
        connectTimeout: 5
        readTimeout: 15
        containerCapStr: "100"
        maxRequestsPerHostStr: "32"
        retentionTimeout: 5
        
        templates:
          - name: "default-agent"
            label: "default-agent"
            serviceAccount: "jenkins-agent"
            containers:
              - name: "jnlp"
                image: "jenkins/inbound-agent:latest"
                workingDir: "/home/jenkins/agent"
                resourceRequestCpu: "500m"
                resourceRequestMemory: "1Gi"
                resourceLimitCpu: "1000m"
                resourceLimitMemory: "2Gi"
```

### 2. Dynamic Agent Implementation

#### Custom Agent Images

**Base Agent Dockerfile**
```dockerfile
FROM jenkins/inbound-agent:latest

USER root

# Install common tools
RUN apt-get update && apt-get install -y \
    curl \
    git \
    unzip \
    wget \
    build-essential \
    && rm -rf /var/lib/apt/lists/*

# Install Docker CLI
RUN curl -fsSL https://download.docker.com/linux/ubuntu/gpg | apt-key add - \
    && echo "deb [arch=amd64] https://download.docker.com/linux/ubuntu $(lsb_release -cs) stable" > /etc/apt/sources.list.d/docker.list \
    && apt-get update \
    && apt-get install -y docker-ce-cli \
    && rm -rf /var/lib/apt/lists/*

# Install kubectl
RUN curl -LO "https://dl.k8s.io/release/$(curl -L -s https://dl.k8s.io/release/stable.txt)/bin/linux/amd64/kubectl" \
    && install -o root -g root -m 0755 kubectl /usr/local/bin/kubectl

USER jenkins
```

**Specialized Agent Examples**
```dockerfile
# Python Agent
FROM base-agent:latest
USER root
RUN apt-get update && apt-get install -y python3 python3-pip
RUN pip3 install pytest flake8 black
USER jenkins

# Node.js Agent
FROM base-agent:latest
USER root
RUN curl -fsSL https://deb.nodesource.com/setup_16.x | bash -
RUN apt-get install -y nodejs
RUN npm install -g yarn jest eslint
USER jenkins

# Maven Agent
FROM base-agent:latest
USER root
RUN apt-get update && apt-get install -y openjdk-11-jdk maven
ENV JAVA_HOME=/usr/lib/jvm/java-11-openjdk-amd64
USER jenkins
```

#### Agent Pod Templates
```yaml
apiVersion: v1
kind: Pod
metadata:
  name: jenkins-agent-${BUILD_NUMBER}
  namespace: jenkins-agents
spec:
  serviceAccountName: jenkins-agent
  containers:
  - name: jnlp
    image: ${AGENT_IMAGE}
    env:
    - name: JENKINS_URL
      value: "http://jenkins.jenkins.svc.cluster.local:8080"
    - name: JENKINS_AGENT_NAME
      value: "${AGENT_NAME}"
    - name: JENKINS_SECRET
      valueFrom:
        secretKeyRef:
          name: jenkins-agent-secret
          key: secret
    resources:
      requests:
        memory: "1Gi"
        cpu: "500m"
      limits:
        memory: "2Gi"
        cpu: "1000m"
    volumeMounts:
    - name: workspace-volume
      mountPath: /home/jenkins/agent
    - name: docker-sock
      mountPath: /var/run/docker.sock
  volumes:
  - name: workspace-volume
    emptyDir: {}
  - name: docker-sock
    hostPath:
      path: /var/run/docker.sock
  restartPolicy: Never
```

### 3. Storage Implementation

#### EFS Configuration
```yaml
apiVersion: storage.k8s.io/v1
kind: StorageClass
metadata:
  name: efs-sc
provisioner: efs.csi.aws.com
parameters:
  provisioningMode: efs-ap
  fileSystemId: fs-0123456789abcdef0
  directoryPerms: "0755"
  gidRangeStart: "1000"
  gidRangeEnd: "2000"
  basePath: "/jenkins"
```

#### Persistent Volume Claims
```yaml
apiVersion: v1
kind: PersistentVolumeClaim
metadata:
  name: jenkins-workspace-pvc
  namespace: jenkins
spec:
  accessModes:
    - ReadWriteMany
  storageClassName: efs-sc
  resources:
    requests:
      storage: 100Gi
```

### 4. Auto-scaling Configuration

#### Horizontal Pod Autoscaler
```yaml
apiVersion: autoscaling/v2
kind: HorizontalPodAutoscaler
metadata:
  name: jenkins-agent-hpa
  namespace: jenkins-agents
spec:
  scaleTargetRef:
    apiVersion: apps/v1
    kind: Deployment
    name: jenkins-agent-pool
  minReplicas: 2
  maxReplicas: 50
  metrics:
  - type: Resource
    resource:
      name: cpu
      target:
        type: Utilization
        averageUtilization: 70
  - type: Resource
    resource:
      name: memory
      target:
        type: Utilization
        averageUtilization: 80
  - type: External
    external:
      metric:
        name: jenkins_queue_length
      target:
        type: Value
        value: "5"
```

#### Cluster Autoscaler Configuration
```yaml
apiVersion: apps/v1
kind: Deployment
metadata:
  name: cluster-autoscaler
  namespace: kube-system
spec:
  template:
    spec:
      containers:
      - image: k8s.gcr.io/autoscaling/cluster-autoscaler:v1.21.0
        name: cluster-autoscaler
        command:
        - ./cluster-autoscaler
        - --v=4
        - --stderrthreshold=info
        - --cloud-provider=aws
        - --skip-nodes-with-local-storage=false
        - --expander=least-waste
        - --node-group-auto-discovery=asg:tag=k8s.io/cluster-autoscaler/enabled,k8s.io/cluster-autoscaler/jenkins-eks
        - --balance-similar-node-groups
        - --skip-nodes-with-system-pods=false
```

### 5. Monitoring and Observability

#### Prometheus Configuration
```yaml
apiVersion: v1
kind: ConfigMap
metadata:
  name: prometheus-config
data:
  prometheus.yml: |
    global:
      scrape_interval: 15s
    scrape_configs:
    - job_name: 'jenkins'
      static_configs:
      - targets: ['jenkins.jenkins.svc.cluster.local:8080']
      metrics_path: '/prometheus'
    - job_name: 'kubernetes-pods'
      kubernetes_sd_configs:
      - role: pod
        namespaces:
          names:
          - jenkins
          - jenkins-agents
```

#### Grafana Dashboard Configuration
```json
{
  "dashboard": {
    "title": "Jenkins Performance Dashboard",
    "panels": [
      {
        "title": "Build Queue Length",
        "type": "stat",
        "targets": [
          {
            "expr": "jenkins_queue_size_value",
            "legendFormat": "Queue Size"
          }
        ]
      },
      {
        "title": "Active Agents",
        "type": "stat",
        "targets": [
          {
            "expr": "jenkins_node_online_value",
            "legendFormat": "Online Agents"
          }
        ]
      },
      {
        "title": "Build Success Rate",
        "type": "stat",
        "targets": [
          {
            "expr": "rate(jenkins_builds_success_total[5m]) / rate(jenkins_builds_total[5m]) * 100",
            "legendFormat": "Success Rate %"
          }
        ]
      }
    ]
  }
}
```

### 6. Security Implementation

#### RBAC Configuration
```yaml
apiVersion: v1
kind: ServiceAccount
metadata:
  name: jenkins
  namespace: jenkins

---
apiVersion: rbac.authorization.k8s.io/v1
kind: ClusterRole
metadata:
  name: jenkins
rules:
- apiGroups: [""]
  resources: ["pods", "pods/log", "pods/exec"]
  verbs: ["create", "delete", "get", "list", "patch", "update", "watch"]
- apiGroups: [""]
  resources: ["secrets", "configmaps"]
  verbs: ["get", "list", "create", "update"]
- apiGroups: ["apps"]
  resources: ["deployments", "replicasets"]
  verbs: ["get", "list", "create", "update", "delete"]

---
apiVersion: rbac.authorization.k8s.io/v1
kind: ClusterRoleBinding
metadata:
  name: jenkins
roleRef:
  apiGroup: rbac.authorization.k8s.io
  kind: ClusterRole
  name: jenkins
subjects:
- kind: ServiceAccount
  name: jenkins
  namespace: jenkins
```

#### Network Policies
```yaml
apiVersion: networking.k8s.io/v1
kind: NetworkPolicy
metadata:
  name: jenkins-network-policy
  namespace: jenkins
spec:
  podSelector:
    matchLabels:
      app: jenkins-master
  policyTypes:
  - Ingress
  - Egress
  ingress:
  - from:
    - namespaceSelector:
        matchLabels:
          name: jenkins-agents
    - podSelector:
        matchLabels:
          app: jenkins-agent
    ports:
    - protocol: TCP
      port: 8080
    - protocol: TCP
      port: 50000
  egress:
  - to: []
    ports:
    - protocol: TCP
      port: 443
    - protocol: TCP
      port: 80
```

### 7. Backup and Recovery

#### Backup CronJob
```yaml
apiVersion: batch/v1
kind: CronJob
metadata:
  name: jenkins-backup
  namespace: jenkins
spec:
  schedule: "0 2 * * *"
  jobTemplate:
    spec:
      template:
        spec:
          containers:
          - name: backup
            image: amazon/aws-cli:latest
            command:
            - /bin/sh
            - -c
            - |
              aws s3 sync /var/jenkins_home s3://jenkins-backup-bucket/$(date +%Y%m%d)/ \
                --exclude "workspace/*" \
                --exclude "logs/*" \
                --exclude ".cache/*"
            volumeMounts:
            - name: jenkins-home
              mountPath: /var/jenkins_home
              readOnly: true
            env:
            - name: AWS_DEFAULT_REGION
              value: "us-west-2"
          volumes:
          - name: jenkins-home
            persistentVolumeClaim:
              claimName: jenkins-master-jenkins-home-jenkins-master-0
          restartPolicy: OnFailure
```

### 8. Pipeline Examples

#### Kubernetes-based Pipeline
```groovy
pipeline {
    agent {
        kubernetes {
            yaml """
                apiVersion: v1
                kind: Pod
                spec:
                  containers:
                  - name: maven
                    image: maven:3.8.1-adoptopenjdk-11
                    command:
                    - cat
                    tty: true
                  - name: docker
                    image: docker:dind
                    securityContext:
                      privileged: true
            """
        }
    }
    
    stages {
        stage('Build') {
            steps {
                container('maven') {
                    sh 'mvn clean compile'
                }
            }
        }
        
        stage('Test') {
            steps {
                container('maven') {
                    sh 'mvn test'
                }
            }
        }
        
        stage('Package') {
            steps {
                container('maven') {
                    sh 'mvn package'
                }
            }
        }
        
        stage('Docker Build') {
            steps {
                container('docker') {
                    sh 'docker build -t myapp:${BUILD_NUMBER} .'
                    sh 'docker tag myapp:${BUILD_NUMBER} ${ECR_REGISTRY}/myapp:${BUILD_NUMBER}'
                    sh 'docker push ${ECR_REGISTRY}/myapp:${BUILD_NUMBER}'
                }
            }
        }
    }
}
```
