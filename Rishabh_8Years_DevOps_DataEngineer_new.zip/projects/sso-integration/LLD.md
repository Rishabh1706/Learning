# SSO Integration Project - Low Level Design
*Detailed Technical Implementation Specification*

## 🏗️ Component Architecture

### 1. FastAPI Application Structure

```
sso-service/
├── app/
│   ├── __init__.py
│   ├── main.py                 # FastAPI application setup
│   ├── config.py              # Configuration management
│   ├── dependencies.py        # Dependency injection
│   ├── middleware.py          # Custom middleware
│   │
│   ├── auth/
│   │   ├── __init__.py
│   │   ├── oauth2.py          # OAuth 2.0 implementation
│   │   ├── saml.py            # SAML 2.0 implementation
│   │   ├── jwt_handler.py     # JWT token management
│   │   ├── session.py         # Session management
│   │   └── mfa.py             # Multi-factor authentication
│   │
│   ├── directory/
│   │   ├── __init__.py
│   │   ├── ldap_client.py     # LDAP/AD integration
│   │   ├── azure_ad.py        # Azure AD integration
│   │   └── user_sync.py       # User synchronization
│   │
│   ├── models/
│   │   ├── __init__.py
│   │   ├── user.py            # User data models
│   │   ├── session.py         # Session models
│   │   ├── client.py          # OAuth client models
│   │   └── audit.py           # Audit log models
│   │
│   ├── api/
│   │   ├── __init__.py
│   │   ├── auth.py            # Authentication endpoints
│   │   ├── oauth.py           # OAuth endpoints
│   │   ├── saml.py            # SAML endpoints
│   │   ├── admin.py           # Admin endpoints
│   │   └── health.py          # Health check endpoints
│   │
│   ├── services/
│   │   ├── __init__.py
│   │   ├── auth_service.py    # Authentication business logic
│   │   ├── token_service.py   # Token management
│   │   ├── session_service.py # Session management
│   │   └── audit_service.py   # Audit logging
│   │
│   ├── database/
│   │   ├── __init__.py
│   │   ├── connection.py      # Database connection
│   │   ├── models.py          # SQLAlchemy models
│   │   └── migrations/        # Alembic migrations
│   │
│   ├── cache/
│   │   ├── __init__.py
│   │   ├── redis_client.py    # Redis connection
│   │   └── session_store.py   # Session storage
│   │
│   └── utils/
│       ├── __init__.py
│       ├── security.py        # Security utilities
│       ├── validators.py      # Input validation
│       └── exceptions.py      # Custom exceptions
│
├── tests/
├── docker/
├── kubernetes/
└── requirements.txt
```

## 🔐 Core Implementation Details

### 1. JWT Token Management

```python
# app/auth/jwt_handler.py
import jwt
from datetime import datetime, timedelta
from typing import Optional, Dict, Any
from app.config import settings

class JWTHandler:
    def __init__(self):
        self.secret_key = settings.JWT_SECRET_KEY
        self.algorithm = settings.JWT_ALGORITHM
        self.access_token_expire = settings.ACCESS_TOKEN_EXPIRE_MINUTES
        self.refresh_token_expire = settings.REFRESH_TOKEN_EXPIRE_DAYS

    def create_access_token(
        self, 
        subject: str, 
        scopes: List[str] = None,
        additional_claims: Dict[str, Any] = None
    ) -> str:
        """Create JWT access token with user claims"""
        expire = datetime.utcnow() + timedelta(minutes=self.access_token_expire)
        
        payload = {
            "sub": subject,  # User ID
            "exp": expire,
            "iat": datetime.utcnow(),
            "type": "access",
            "scopes": scopes or []
        }
        
        if additional_claims:
            payload.update(additional_claims)
            
        return jwt.encode(payload, self.secret_key, algorithm=self.algorithm)

    def create_refresh_token(self, subject: str) -> str:
        """Create refresh token for token renewal"""
        expire = datetime.utcnow() + timedelta(days=self.refresh_token_expire)
        
        payload = {
            "sub": subject,
            "exp": expire,
            "iat": datetime.utcnow(),
            "type": "refresh"
        }
        
        return jwt.encode(payload, self.secret_key, algorithm=self.algorithm)

    def verify_token(self, token: str) -> Optional[Dict[str, Any]]:
        """Verify and decode JWT token"""
        try:
            payload = jwt.decode(
                token, 
                self.secret_key, 
                algorithms=[self.algorithm]
            )
            return payload
        except jwt.ExpiredSignatureError:
            raise TokenExpiredException("Token has expired")
        except jwt.JWTError:
            raise InvalidTokenException("Invalid token")

    def refresh_access_token(self, refresh_token: str) -> str:
        """Generate new access token from refresh token"""
        payload = self.verify_token(refresh_token)
        
        if payload.get("type") != "refresh":
            raise InvalidTokenException("Invalid refresh token")
            
        user_id = payload.get("sub")
        # Get fresh user data and scopes
        user = await get_user_by_id(user_id)
        scopes = await get_user_scopes(user_id)
        
        return self.create_access_token(user_id, scopes)
```

### 2. OAuth 2.0 Implementation

```python
# app/auth/oauth2.py
from fastapi import HTTPException, Depends, Query
from fastapi.security import OAuth2AuthorizationCodeBearer
from typing import Optional
import secrets
import hashlib

class OAuth2Handler:
    def __init__(self):
        self.authorization_codes = {}  # In production, use Redis
        self.code_expire_minutes = 10

    async def authorize(
        self,
        response_type: str,
        client_id: str,
        redirect_uri: str,
        scope: str,
        state: Optional[str] = None,
        code_challenge: Optional[str] = None,
        code_challenge_method: Optional[str] = None
    ):
        """OAuth 2.0 authorization endpoint"""
        
        # Validate client
        client = await self.validate_client(client_id, redirect_uri)
        if not client:
            raise HTTPException(status_code=400, detail="Invalid client")

        # Validate response type
        if response_type != "code":
            raise HTTPException(status_code=400, detail="Unsupported response type")

        # Generate authorization code
        auth_code = secrets.token_urlsafe(32)
        
        # Store authorization code with metadata
        self.authorization_codes[auth_code] = {
            "client_id": client_id,
            "redirect_uri": redirect_uri,
            "scope": scope,
            "code_challenge": code_challenge,
            "code_challenge_method": code_challenge_method,
            "expires_at": datetime.utcnow() + timedelta(minutes=self.code_expire_minutes),
            "user_id": None  # Set after user authentication
        }

        # Redirect to login if user not authenticated
        # Otherwise redirect with authorization code
        return {
            "redirect_uri": f"{redirect_uri}?code={auth_code}&state={state}"
        }

    async def token_exchange(
        self,
        grant_type: str,
        code: Optional[str] = None,
        redirect_uri: Optional[str] = None,
        client_id: Optional[str] = None,
        client_secret: Optional[str] = None,
        code_verifier: Optional[str] = None,
        refresh_token: Optional[str] = None
    ):
        """OAuth 2.0 token endpoint"""
        
        if grant_type == "authorization_code":
            return await self._handle_authorization_code_grant(
                code, redirect_uri, client_id, client_secret, code_verifier
            )
        elif grant_type == "refresh_token":
            return await self._handle_refresh_token_grant(refresh_token, client_id)
        else:
            raise HTTPException(status_code=400, detail="Unsupported grant type")

    async def _handle_authorization_code_grant(
        self, code, redirect_uri, client_id, client_secret, code_verifier
    ):
        """Handle authorization code grant flow"""
        
        # Validate authorization code
        if code not in self.authorization_codes:
            raise HTTPException(status_code=400, detail="Invalid authorization code")
            
        code_data = self.authorization_codes[code]
        
        # Check expiration
        if datetime.utcnow() > code_data["expires_at"]:
            del self.authorization_codes[code]
            raise HTTPException(status_code=400, detail="Authorization code expired")

        # Validate client
        if code_data["client_id"] != client_id:
            raise HTTPException(status_code=400, detail="Client mismatch")

        # Validate redirect URI
        if code_data["redirect_uri"] != redirect_uri:
            raise HTTPException(status_code=400, detail="Redirect URI mismatch")

        # Validate PKCE if used
        if code_data.get("code_challenge"):
            if not code_verifier:
                raise HTTPException(status_code=400, detail="Code verifier required")
                
            if code_data["code_challenge_method"] == "S256":
                challenge = hashlib.sha256(code_verifier.encode()).digest()
                challenge_b64 = base64.urlsafe_b64encode(challenge).decode().rstrip("=")
                if challenge_b64 != code_data["code_challenge"]:
                    raise HTTPException(status_code=400, detail="Invalid code verifier")

        # Generate tokens
        user_id = code_data["user_id"]
        scopes = code_data["scope"].split(" ") if code_data["scope"] else []
        
        jwt_handler = JWTHandler()
        access_token = jwt_handler.create_access_token(user_id, scopes)
        refresh_token = jwt_handler.create_refresh_token(user_id)

        # Clean up authorization code
        del self.authorization_codes[code]

        return {
            "access_token": access_token,
            "token_type": "Bearer",
            "expires_in": settings.ACCESS_TOKEN_EXPIRE_MINUTES * 60,
            "refresh_token": refresh_token,
            "scope": " ".join(scopes)
        }
```

### 3. LDAP Integration

```python
# app/directory/ldap_client.py
import ldap3
from ldap3 import Server, Connection, ALL, NTLM
from typing import Optional, Dict, List
from app.config import settings

class LDAPClient:
    def __init__(self):
        self.server = Server(
            settings.LDAP_SERVER,
            port=settings.LDAP_PORT,
            use_ssl=settings.LDAP_USE_SSL,
            get_info=ALL
        )
        self.base_dn = settings.LDAP_BASE_DN
        self.bind_user = settings.LDAP_BIND_USER
        self.bind_password = settings.LDAP_BIND_PASSWORD

    async def authenticate_user(self, username: str, password: str) -> Optional[Dict]:
        """Authenticate user against LDAP"""
        try:
            # Create user DN
            user_dn = f"cn={username},{self.base_dn}"
            
            # Attempt to bind with user credentials
            conn = Connection(
                self.server,
                user=user_dn,
                password=password,
                authentication=NTLM if settings.LDAP_USE_NTLM else None
            )
            
            if conn.bind():
                # Get user attributes
                user_info = await self.get_user_info(username)
                conn.unbind()
                return user_info
            else:
                return None
                
        except Exception as e:
            logger.error(f"LDAP authentication error: {e}")
            return None

    async def get_user_info(self, username: str) -> Optional[Dict]:
        """Retrieve user information from LDAP"""
        try:
            conn = Connection(
                self.server,
                user=self.bind_user,
                password=self.bind_password
            )
            
            if conn.bind():
                # Search for user
                search_filter = f"(sAMAccountName={username})"
                conn.search(
                    self.base_dn,
                    search_filter,
                    attributes=[
                        'cn', 'mail', 'displayName', 'memberOf',
                        'objectGUID', 'userAccountControl'
                    ]
                )
                
                if conn.entries:
                    entry = conn.entries[0]
                    user_info = {
                        'username': username,
                        'email': str(entry.mail),
                        'display_name': str(entry.displayName),
                        'groups': [str(group) for group in entry.memberOf],
                        'guid': str(entry.objectGUID),
                        'enabled': not bool(int(str(entry.userAccountControl)) & 2)
                    }
                    conn.unbind()
                    return user_info
                    
                conn.unbind()
                return None
                
        except Exception as e:
            logger.error(f"LDAP user info error: {e}")
            return None

    async def get_user_groups(self, username: str) -> List[str]:
        """Get user group memberships"""
        user_info = await self.get_user_info(username)
        if user_info:
            return user_info.get('groups', [])
        return []

    async def sync_users(self) -> int:
        """Sync users from LDAP to local database"""
        synced_count = 0
        try:
            conn = Connection(
                self.server,
                user=self.bind_user,
                password=self.bind_password
            )
            
            if conn.bind():
                # Search for all users
                search_filter = "(objectClass=person)"
                conn.search(
                    self.base_dn,
                    search_filter,
                    attributes=['cn', 'mail', 'displayName', 'sAMAccountName']
                )
                
                for entry in conn.entries:
                    username = str(entry.sAMAccountName)
                    if username:
                        await self.sync_user_to_db(entry)
                        synced_count += 1
                        
                conn.unbind()
                
        except Exception as e:
            logger.error(f"LDAP sync error: {e}")
            
        return synced_count
```

### 4. Session Management

```python
# app/cache/session_store.py
import redis.asyncio as redis
import json
from datetime import timedelta
from typing import Optional, Dict, Any
from app.config import settings

class SessionStore:
    def __init__(self):
        self.redis = redis.from_url(
            settings.REDIS_URL,
            encoding="utf-8",
            decode_responses=True
        )
        self.session_expire = timedelta(hours=settings.SESSION_EXPIRE_HOURS)

    async def create_session(
        self, 
        user_id: str, 
        session_data: Dict[str, Any]
    ) -> str:
        """Create new user session"""
        session_id = secrets.token_urlsafe(32)
        session_key = f"session:{session_id}"
        
        session_info = {
            "user_id": user_id,
            "created_at": datetime.utcnow().isoformat(),
            "last_accessed": datetime.utcnow().isoformat(),
            "ip_address": session_data.get("ip_address"),
            "user_agent": session_data.get("user_agent"),
            "scopes": session_data.get("scopes", [])
        }
        
        await self.redis.setex(
            session_key,
            self.session_expire,
            json.dumps(session_info)
        )
        
        # Track user sessions
        user_sessions_key = f"user_sessions:{user_id}"
        await self.redis.sadd(user_sessions_key, session_id)
        await self.redis.expire(user_sessions_key, self.session_expire)
        
        return session_id

    async def get_session(self, session_id: str) -> Optional[Dict[str, Any]]:
        """Retrieve session information"""
        session_key = f"session:{session_id}"
        session_data = await self.redis.get(session_key)
        
        if session_data:
            session_info = json.loads(session_data)
            
            # Update last accessed time
            session_info["last_accessed"] = datetime.utcnow().isoformat()
            await self.redis.setex(
                session_key,
                self.session_expire,
                json.dumps(session_info)
            )
            
            return session_info
            
        return None

    async def invalidate_session(self, session_id: str) -> bool:
        """Invalidate a specific session"""
        session_key = f"session:{session_id}"
        session_data = await self.redis.get(session_key)
        
        if session_data:
            session_info = json.loads(session_data)
            user_id = session_info["user_id"]
            
            # Remove from Redis
            await self.redis.delete(session_key)
            
            # Remove from user sessions set
            user_sessions_key = f"user_sessions:{user_id}"
            await self.redis.srem(user_sessions_key, session_id)
            
            return True
            
        return False

    async def invalidate_user_sessions(self, user_id: str) -> int:
        """Invalidate all sessions for a user"""
        user_sessions_key = f"user_sessions:{user_id}"
        session_ids = await self.redis.smembers(user_sessions_key)
        
        count = 0
        for session_id in session_ids:
            if await self.invalidate_session(session_id):
                count += 1
                
        return count
```

### 5. API Endpoints

```python
# app/api/auth.py
from fastapi import APIRouter, Depends, HTTPException, Request
from fastapi.security import HTTPBearer
from app.auth.jwt_handler import JWTHandler
from app.directory.ldap_client import LDAPClient
from app.cache.session_store import SessionStore

router = APIRouter(prefix="/auth", tags=["authentication"])
security = HTTPBearer()

@router.post("/login")
async def login(
    request: Request,
    credentials: UserCredentials,
    ldap_client: LDAPClient = Depends(),
    session_store: SessionStore = Depends(),
    jwt_handler: JWTHandler = Depends()
):
    """Authenticate user and create session"""
    
    # Authenticate against LDAP
    user_info = await ldap_client.authenticate_user(
        credentials.username, 
        credentials.password
    )
    
    if not user_info:
        raise HTTPException(
            status_code=401, 
            detail="Invalid credentials"
        )
    
    # Create local user record if needed
    user = await get_or_create_user(user_info)
    
    # Get user scopes/permissions
    scopes = await get_user_scopes(user.id)
    
    # Create session
    session_data = {
        "ip_address": request.client.host,
        "user_agent": request.headers.get("user-agent"),
        "scopes": scopes
    }
    session_id = await session_store.create_session(user.id, session_data)
    
    # Generate JWT tokens
    access_token = jwt_handler.create_access_token(
        user.id, 
        scopes,
        {"session_id": session_id}
    )
    refresh_token = jwt_handler.create_refresh_token(user.id)
    
    # Log successful authentication
    await audit_log(
        "authentication_success",
        user_id=user.id,
        ip_address=request.client.host
    )
    
    return {
        "access_token": access_token,
        "refresh_token": refresh_token,
        "token_type": "Bearer",
        "expires_in": settings.ACCESS_TOKEN_EXPIRE_MINUTES * 60,
        "user": {
            "id": user.id,
            "username": user.username,
            "display_name": user.display_name,
            "email": user.email
        }
    }

@router.post("/logout")
async def logout(
    token: str = Depends(security),
    jwt_handler: JWTHandler = Depends(),
    session_store: SessionStore = Depends()
):
    """Logout user and invalidate session"""
    
    try:
        payload = jwt_handler.verify_token(token.credentials)
        session_id = payload.get("session_id")
        user_id = payload.get("sub")
        
        if session_id:
            await session_store.invalidate_session(session_id)
            
        await audit_log(
            "logout",
            user_id=user_id
        )
        
        return {"message": "Logged out successfully"}
        
    except Exception as e:
        raise HTTPException(status_code=401, detail="Invalid token")

@router.get("/me")
async def get_current_user(
    current_user: User = Depends(get_current_user)
):
    """Get current user information"""
    return {
        "id": current_user.id,
        "username": current_user.username,
        "display_name": current_user.display_name,
        "email": current_user.email,
        "scopes": current_user.scopes
    }
```

### 6. Middleware Implementation

```python
# app/middleware.py
from fastapi import Request, Response
from starlette.middleware.base import BaseHTTPMiddleware
import time
import logging

class SecurityMiddleware(BaseHTTPMiddleware):
    async def dispatch(self, request: Request, call_next):
        # Add security headers
        response = await call_next(request)
        
        # Security headers
        response.headers["X-Content-Type-Options"] = "nosniff"
        response.headers["X-Frame-Options"] = "DENY"
        response.headers["X-XSS-Protection"] = "1; mode=block"
        response.headers["Strict-Transport-Security"] = "max-age=31536000; includeSubDomains"
        response.headers["Content-Security-Policy"] = "default-src 'self'"
        
        return response

class AuditMiddleware(BaseHTTPMiddleware):
    async def dispatch(self, request: Request, call_next):
        start_time = time.time()
        
        # Log request
        logger.info(
            f"Request: {request.method} {request.url} "
            f"from {request.client.host}"
        )
        
        response = await call_next(request)
        
        # Log response
        process_time = time.time() - start_time
        logger.info(
            f"Response: {response.status_code} "
            f"processed in {process_time:.3f}s"
        )
        
        return response
```

This low-level design provides the detailed implementation structure needed to build a production-ready SSO service with FastAPI, including all the core components for authentication, session management, and security.
