# Enterprise AI-Powered Analytics Platform - Low-Level Design

## 1. Service Implementation Details

### 1.1 User Management Service

#### 1.1.1 Service Architecture
```python
# Directory Structure
user-service/
├── app/
│   ├── __init__.py
│   ├── main.py                 # FastAPI application entry point
│   ├── models/
│   │   ├── __init__.py
│   │   ├── user.py            # User data models
│   │   ├── role.py            # Role and permission models
│   │   └── session.py         # Session management models
│   ├── api/
│   │   ├── __init__.py
│   │   ├── auth.py            # Authentication endpoints
│   │   ├── users.py           # User management endpoints
│   │   └── roles.py           # Role management endpoints
│   ├── services/
│   │   ├── __init__.py
│   │   ├── auth_service.py    # Authentication business logic
│   │   ├── user_service.py    # User management logic
│   │   └── jwt_service.py     # JWT token management
│   ├── repositories/
│   │   ├── __init__.py
│   │   ├── user_repository.py # User data access layer
│   │   └── role_repository.py # Role data access layer
│   └── utils/
│       ├── __init__.py
│       ├── password.py        # Password hashing utilities
│       └── validators.py      # Input validation
├── tests/
├── requirements.txt
└── Dockerfile
```

#### 1.1.2 Data Models
```python
# models/user.py
from sqlalchemy import Column, Integer, String, DateTime, Boolean
from sqlalchemy.ext.declarative import declarative_base
from datetime import datetime

Base = declarative_base()

class User(Base):
    __tablename__ = "users"
    
    id = Column(Integer, primary_key=True, index=True)
    email = Column(String, unique=True, index=True, nullable=False)
    username = Column(String, unique=True, index=True, nullable=False)
    hashed_password = Column(String, nullable=False)
    first_name = Column(String, nullable=False)
    last_name = Column(String, nullable=False)
    is_active = Column(Boolean, default=True)
    is_verified = Column(Boolean, default=False)
    created_at = Column(DateTime, default=datetime.utcnow)
    updated_at = Column(DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)
    last_login = Column(DateTime, nullable=True)
    
class UserProfile(Base):
    __tablename__ = "user_profiles"
    
    id = Column(Integer, primary_key=True, index=True)
    user_id = Column(Integer, ForeignKey("users.id"), unique=True)
    avatar_url = Column(String, nullable=True)
    bio = Column(String, nullable=True)
    timezone = Column(String, default="UTC")
    language = Column(String, default="en")
    notification_preferences = Column(JSON)
```

#### 1.1.3 API Implementation
```python
# api/auth.py
from fastapi import APIRouter, Depends, HTTPException, status
from fastapi.security import OAuth2PasswordRequestForm
from ..services.auth_service import AuthService
from ..models.user import User

router = APIRouter(prefix="/auth", tags=["authentication"])

@router.post("/login")
async def login(
    form_data: OAuth2PasswordRequestForm = Depends(),
    auth_service: AuthService = Depends()
):
    user = await auth_service.authenticate_user(
        form_data.username, 
        form_data.password
    )
    if not user:
        raise HTTPException(
            status_code=status.HTTP_401_UNAUTHORIZED,
            detail="Incorrect username or password"
        )
    
    access_token = auth_service.create_access_token(
        data={"sub": user.email}
    )
    return {
        "access_token": access_token,
        "token_type": "bearer",
        "expires_in": 3600
    }

@router.post("/register")
async def register(
    user_data: UserCreateSchema,
    auth_service: AuthService = Depends()
):
    existing_user = await auth_service.get_user_by_email(user_data.email)
    if existing_user:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail="Email already registered"
        )
    
    user = await auth_service.create_user(user_data)
    return {"message": "User created successfully", "user_id": user.id}
```

### 1.2 Data Ingestion Service

#### 1.2.1 Kafka Consumer Implementation
```python
# services/kafka_consumer.py
import asyncio
import json
from kafka import KafkaConsumer
from typing import Dict, Any
import logging

class KafkaDataIngestion:
    def __init__(self, bootstrap_servers: str, topics: list):
        self.bootstrap_servers = bootstrap_servers
        self.topics = topics
        self.consumer = None
        self.logger = logging.getLogger(__name__)
        
    async def start_consuming(self):
        """Start consuming messages from Kafka topics"""
        self.consumer = KafkaConsumer(
            *self.topics,
            bootstrap_servers=self.bootstrap_servers,
            value_deserializer=lambda x: json.loads(x.decode('utf-8')),
            group_id='analytics-platform-group',
            auto_offset_reset='latest'
        )
        
        try:
            for message in self.consumer:
                await self.process_message(message)
        except Exception as e:
            self.logger.error(f"Error consuming message: {e}")
        finally:
            self.consumer.close()
    
    async def process_message(self, message):
        """Process individual Kafka message"""
        try:
            topic = message.topic
            data = message.value
            timestamp = message.timestamp
            
            # Validate message structure
            validated_data = await self.validate_message(data, topic)
            
            # Transform data based on topic
            transformed_data = await self.transform_data(validated_data, topic)
            
            # Store in appropriate storage
            await self.store_data(transformed_data, topic)
            
            self.logger.info(f"Processed message from topic {topic}")
            
        except Exception as e:
            self.logger.error(f"Error processing message: {e}")
            await self.handle_error(message, e)
    
    async def validate_message(self, data: Dict[Any, Any], topic: str) -> Dict[Any, Any]:
        """Validate message against schema"""
        schema_validator = SchemaValidator.get_validator(topic)
        return schema_validator.validate(data)
    
    async def transform_data(self, data: Dict[Any, Any], topic: str) -> Dict[Any, Any]:
        """Transform data based on business rules"""
        transformer = DataTransformer.get_transformer(topic)
        return transformer.transform(data)
    
    async def store_data(self, data: Dict[Any, Any], topic: str):
        """Store data in appropriate storage system"""
        storage_router = StorageRouter.get_storage(topic)
        await storage_router.store(data)
```

#### 1.2.2 Stream Processing with Apache Spark
```python
# services/spark_streaming.py
from pyspark.sql import SparkSession
from pyspark.sql.functions import *
from pyspark.sql.types import *

class SparkStreamProcessor:
    def __init__(self, app_name: str = "AnalyticsPlatformStreaming"):
        self.spark = SparkSession.builder \
            .appName(app_name) \
            .config("spark.sql.streaming.checkpointLocation", "/tmp/checkpoint") \
            .getOrCreate()
        
        self.spark.sparkContext.setLogLevel("WARN")
    
    def create_kafka_stream(self, kafka_servers: str, topics: str):
        """Create streaming DataFrame from Kafka"""
        return self.spark \
            .readStream \
            .format("kafka") \
            .option("kafka.bootstrap.servers", kafka_servers) \
            .option("subscribe", topics) \
            .option("startingOffsets", "latest") \
            .load()
    
    def process_sensor_data(self, stream_df):
        """Process IoT sensor data stream"""
        # Parse JSON data
        schema = StructType([
            StructField("device_id", StringType(), True),
            StructField("timestamp", TimestampType(), True),
            StructField("temperature", DoubleType(), True),
            StructField("humidity", DoubleType(), True),
            StructField("pressure", DoubleType(), True)
        ])
        
        parsed_df = stream_df \
            .select(from_json(col("value").cast("string"), schema).alias("data")) \
            .select("data.*")
        
        # Add derived columns
        enriched_df = parsed_df \
            .withColumn("hour", hour(col("timestamp"))) \
            .withColumn("day_of_week", dayofweek(col("timestamp"))) \
            .withColumn("temperature_status", 
                       when(col("temperature") > 30, "HIGH")
                       .when(col("temperature") < 10, "LOW")
                       .otherwise("NORMAL"))
        
        # Windowed aggregations
        windowed_df = enriched_df \
            .groupBy(
                window(col("timestamp"), "5 minutes"),
                col("device_id")
            ) \
            .agg(
                avg("temperature").alias("avg_temperature"),
                max("temperature").alias("max_temperature"),
                min("temperature").alias("min_temperature"),
                avg("humidity").alias("avg_humidity"),
                count("*").alias("record_count")
            )
        
        return windowed_df
    
    def write_to_storage(self, df, output_mode="append", format_type="delta"):
        """Write streaming data to storage"""
        query = df.writeStream \
            .outputMode(output_mode) \
            .format(format_type) \
            .option("path", "/data/sensor_aggregated") \
            .option("checkpointLocation", "/tmp/checkpoint/sensor") \
            .trigger(processingTime='30 seconds') \
            .start()
        
        return query
```

### 1.3 ML Model Service

#### 1.3.1 Model Serving Infrastructure
```python
# services/ml_model_service.py
import mlflow
import mlflow.sklearn
import mlflow.tensorflow
from typing import Any, Dict, List
import numpy as np
import pandas as pd
from abc import ABC, abstractmethod

class ModelPredictor(ABC):
    @abstractmethod
    async def predict(self, data: Any) -> Any:
        pass
    
    @abstractmethod
    async def predict_batch(self, data: List[Any]) -> List[Any]:
        pass

class MLflowModelPredictor(ModelPredictor):
    def __init__(self, model_uri: str, model_name: str):
        self.model_uri = model_uri
        self.model_name = model_name
        self.model = None
        self.load_model()
    
    def load_model(self):
        """Load model from MLflow"""
        try:
            self.model = mlflow.pyfunc.load_model(self.model_uri)
            print(f"Model {self.model_name} loaded successfully")
        except Exception as e:
            print(f"Error loading model {self.model_name}: {e}")
            raise
    
    async def predict(self, data: Dict[str, Any]) -> Dict[str, Any]:
        """Single prediction"""
        try:
            # Convert input data to DataFrame
            input_df = pd.DataFrame([data])
            
            # Make prediction
            prediction = self.model.predict(input_df)
            
            # Format response
            result = {
                "model_name": self.model_name,
                "prediction": prediction.tolist() if hasattr(prediction, 'tolist') else prediction,
                "confidence": self._calculate_confidence(input_df, prediction)
            }
            
            return result
            
        except Exception as e:
            raise Exception(f"Prediction error: {e}")
    
    async def predict_batch(self, data: List[Dict[str, Any]]) -> List[Dict[str, Any]]:
        """Batch prediction"""
        try:
            # Convert batch data to DataFrame
            input_df = pd.DataFrame(data)
            
            # Make batch predictions
            predictions = self.model.predict(input_df)
            
            # Format batch response
            results = []
            for i, prediction in enumerate(predictions):
                result = {
                    "index": i,
                    "model_name": self.model_name,
                    "prediction": prediction.tolist() if hasattr(prediction, 'tolist') else prediction,
                    "input_data": data[i]
                }
                results.append(result)
            
            return results
            
        except Exception as e:
            raise Exception(f"Batch prediction error: {e}")
    
    def _calculate_confidence(self, input_df: pd.DataFrame, prediction: Any) -> float:
        """Calculate prediction confidence score"""
        # Implement confidence calculation logic
        # This is a placeholder implementation
        return 0.95

class ModelManager:
    def __init__(self):
        self.models: Dict[str, ModelPredictor] = {}
        self.model_metadata: Dict[str, Dict] = {}
    
    async def load_model(self, model_name: str, model_uri: str, metadata: Dict = None):
        """Load a model into memory"""
        try:
            predictor = MLflowModelPredictor(model_uri, model_name)
            self.models[model_name] = predictor
            self.model_metadata[model_name] = metadata or {}
            print(f"Model {model_name} loaded and ready for serving")
        except Exception as e:
            print(f"Failed to load model {model_name}: {e}")
            raise
    
    async def predict(self, model_name: str, data: Dict[str, Any]) -> Dict[str, Any]:
        """Make prediction using specified model"""
        if model_name not in self.models:
            raise Exception(f"Model {model_name} not loaded")
        
        return await self.models[model_name].predict(data)
    
    async def predict_batch(self, model_name: str, data: List[Dict[str, Any]]) -> List[Dict[str, Any]]:
        """Make batch prediction using specified model"""
        if model_name not in self.models:
            raise Exception(f"Model {model_name} not loaded")
        
        return await self.models[model_name].predict_batch(data)
    
    def get_available_models(self) -> List[str]:
        """Get list of available models"""
        return list(self.models.keys())
    
    def get_model_metadata(self, model_name: str) -> Dict:
        """Get metadata for a specific model"""
        return self.model_metadata.get(model_name, {})
```

#### 1.3.2 A/B Testing Framework
```python
# services/ab_testing_service.py
import random
import hashlib
from typing import Dict, Any, List
from enum import Enum
from datetime import datetime, timedelta

class ExperimentStatus(Enum):
    DRAFT = "draft"
    ACTIVE = "active"
    PAUSED = "paused"
    COMPLETED = "completed"

class ABTestExperiment:
    def __init__(self, 
                 experiment_id: str,
                 name: str,
                 model_variants: Dict[str, str],
                 traffic_allocation: Dict[str, float],
                 start_date: datetime,
                 end_date: datetime):
        self.experiment_id = experiment_id
        self.name = name
        self.model_variants = model_variants  # {"control": "model_v1", "treatment": "model_v2"}
        self.traffic_allocation = traffic_allocation  # {"control": 0.5, "treatment": 0.5}
        self.start_date = start_date
        self.end_date = end_date
        self.status = ExperimentStatus.DRAFT
        self.metrics = {}
    
    def is_active(self) -> bool:
        """Check if experiment is currently active"""
        now = datetime.utcnow()
        return (self.status == ExperimentStatus.ACTIVE and 
                self.start_date <= now <= self.end_date)
    
    def assign_variant(self, user_id: str) -> str:
        """Assign user to experiment variant"""
        if not self.is_active():
            return "control"
        
        # Use consistent hashing for user assignment
        hash_input = f"{self.experiment_id}:{user_id}"
        hash_value = hashlib.md5(hash_input.encode()).hexdigest()
        hash_int = int(hash_value, 16)
        
        # Convert to probability between 0 and 1
        probability = (hash_int % 1000000) / 1000000.0
        
        # Assign based on traffic allocation
        cumulative_probability = 0
        for variant, allocation in self.traffic_allocation.items():
            cumulative_probability += allocation
            if probability <= cumulative_probability:
                return variant
        
        return "control"  # fallback

class ABTestingService:
    def __init__(self, model_manager):
        self.model_manager = model_manager
        self.experiments: Dict[str, ABTestExperiment] = {}
        self.experiment_results = {}
    
    def create_experiment(self, 
                         experiment_id: str,
                         name: str,
                         model_variants: Dict[str, str],
                         traffic_allocation: Dict[str, float],
                         duration_days: int) -> ABTestExperiment:
        """Create a new A/B test experiment"""
        
        # Validate traffic allocation
        if abs(sum(traffic_allocation.values()) - 1.0) > 0.001:
            raise ValueError("Traffic allocation must sum to 1.0")
        
        start_date = datetime.utcnow()
        end_date = start_date + timedelta(days=duration_days)
        
        experiment = ABTestExperiment(
            experiment_id=experiment_id,
            name=name,
            model_variants=model_variants,
            traffic_allocation=traffic_allocation,
            start_date=start_date,
            end_date=end_date
        )
        
        self.experiments[experiment_id] = experiment
        return experiment
    
    async def get_prediction_with_experiment(self, 
                                           experiment_id: str,
                                           user_id: str,
                                           data: Dict[str, Any]) -> Dict[str, Any]:
        """Get prediction while running A/B test"""
        
        if experiment_id not in self.experiments:
            raise ValueError(f"Experiment {experiment_id} not found")
        
        experiment = self.experiments[experiment_id]
        
        # Assign user to variant
        variant = experiment.assign_variant(user_id)
        model_name = experiment.model_variants[variant]
        
        # Get prediction from assigned model
        prediction_result = await self.model_manager.predict(model_name, data)
        
        # Add experiment metadata to response
        prediction_result.update({
            "experiment_id": experiment_id,
            "variant": variant,
            "model_used": model_name,
            "user_id": user_id
        })
        
        # Log experiment event for analysis
        await self._log_experiment_event(experiment_id, user_id, variant, prediction_result)
        
        return prediction_result
    
    async def _log_experiment_event(self, 
                                  experiment_id: str, 
                                  user_id: str, 
                                  variant: str, 
                                  result: Dict[str, Any]):
        """Log experiment event for later analysis"""
        event = {
            "timestamp": datetime.utcnow().isoformat(),
            "experiment_id": experiment_id,
            "user_id": user_id,
            "variant": variant,
            "prediction": result.get("prediction"),
            "model_name": result.get("model_used")
        }
        
        # Store event in analytics database
        # Implementation depends on chosen storage solution
        pass
    
    def start_experiment(self, experiment_id: str):
        """Start an experiment"""
        if experiment_id in self.experiments:
            self.experiments[experiment_id].status = ExperimentStatus.ACTIVE
    
    def stop_experiment(self, experiment_id: str):
        """Stop an experiment"""
        if experiment_id in self.experiments:
            self.experiments[experiment_id].status = ExperimentStatus.COMPLETED
    
    def get_experiment_results(self, experiment_id: str) -> Dict[str, Any]:
        """Get statistical results for an experiment"""
        # Implement statistical analysis of experiment results
        # This would include metrics like conversion rates, 
        # statistical significance, confidence intervals, etc.
        pass
```

## 2. Database Design and Implementation

### 2.1 PostgreSQL Schema Design

#### 2.1.1 Core Tables
```sql
-- User Management Tables
CREATE TABLE users (
    id SERIAL PRIMARY KEY,
    email VARCHAR(255) UNIQUE NOT NULL,
    username VARCHAR(100) UNIQUE NOT NULL,
    hashed_password VARCHAR(255) NOT NULL,
    first_name VARCHAR(100) NOT NULL,
    last_name VARCHAR(100) NOT NULL,
    is_active BOOLEAN DEFAULT TRUE,
    is_verified BOOLEAN DEFAULT FALSE,
    created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
    updated_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
    last_login TIMESTAMP WITH TIME ZONE
);

CREATE TABLE user_profiles (
    id SERIAL PRIMARY KEY,
    user_id INTEGER UNIQUE REFERENCES users(id) ON DELETE CASCADE,
    avatar_url VARCHAR(500),
    bio TEXT,
    timezone VARCHAR(50) DEFAULT 'UTC',
    language VARCHAR(10) DEFAULT 'en',
    notification_preferences JSONB
);

CREATE TABLE roles (
    id SERIAL PRIMARY KEY,
    name VARCHAR(100) UNIQUE NOT NULL,
    description TEXT,
    permissions JSONB,
    created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

CREATE TABLE user_roles (
    user_id INTEGER REFERENCES users(id) ON DELETE CASCADE,
    role_id INTEGER REFERENCES roles(id) ON DELETE CASCADE,
    assigned_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
    assigned_by INTEGER REFERENCES users(id),
    PRIMARY KEY (user_id, role_id)
);

-- Analytics and ML Tables
CREATE TABLE ml_models (
    id SERIAL PRIMARY KEY,
    name VARCHAR(200) NOT NULL,
    version VARCHAR(50) NOT NULL,
    model_uri VARCHAR(500) NOT NULL,
    model_type VARCHAR(100) NOT NULL,
    framework VARCHAR(100) NOT NULL,
    created_by INTEGER REFERENCES users(id),
    created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
    is_active BOOLEAN DEFAULT TRUE,
    metadata JSONB,
    UNIQUE(name, version)
);

CREATE TABLE experiments (
    id SERIAL PRIMARY KEY,
    experiment_id VARCHAR(100) UNIQUE NOT NULL,
    name VARCHAR(200) NOT NULL,
    description TEXT,
    model_variants JSONB NOT NULL,
    traffic_allocation JSONB NOT NULL,
    start_date TIMESTAMP WITH TIME ZONE NOT NULL,
    end_date TIMESTAMP WITH TIME ZONE NOT NULL,
    status VARCHAR(20) DEFAULT 'draft',
    created_by INTEGER REFERENCES users(id),
    created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

CREATE TABLE experiment_events (
    id SERIAL PRIMARY KEY,
    experiment_id VARCHAR(100) REFERENCES experiments(experiment_id),
    user_id VARCHAR(100) NOT NULL,
    variant VARCHAR(100) NOT NULL,
    model_name VARCHAR(200) NOT NULL,
    prediction JSONB,
    response_time_ms INTEGER,
    timestamp TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
    session_id VARCHAR(100),
    metadata JSONB
);

-- Data Pipeline Tables
CREATE TABLE data_sources (
    id SERIAL PRIMARY KEY,
    name VARCHAR(200) NOT NULL,
    type VARCHAR(100) NOT NULL, -- 'kafka', 'api', 'database', 'file'
    connection_string VARCHAR(500),
    configuration JSONB,
    is_active BOOLEAN DEFAULT TRUE,
    created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
    updated_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

CREATE TABLE pipeline_runs (
    id SERIAL PRIMARY KEY,
    pipeline_name VARCHAR(200) NOT NULL,
    run_id VARCHAR(100) UNIQUE NOT NULL,
    status VARCHAR(50) NOT NULL, -- 'running', 'completed', 'failed'
    start_time TIMESTAMP WITH TIME ZONE NOT NULL,
    end_time TIMESTAMP WITH TIME ZONE,
    records_processed BIGINT DEFAULT 0,
    records_failed BIGINT DEFAULT 0,
    error_message TEXT,
    metadata JSONB
);

-- Indexes for performance
CREATE INDEX idx_users_email ON users(email);
CREATE INDEX idx_users_username ON users(username);
CREATE INDEX idx_users_active ON users(is_active);
CREATE INDEX idx_experiment_events_experiment_id ON experiment_events(experiment_id);
CREATE INDEX idx_experiment_events_timestamp ON experiment_events(timestamp);
CREATE INDEX idx_pipeline_runs_status ON pipeline_runs(status);
CREATE INDEX idx_pipeline_runs_pipeline_name ON pipeline_runs(pipeline_name);
```

#### 2.1.2 Partitioning Strategy
```sql
-- Partition experiment_events by date for better query performance
CREATE TABLE experiment_events (
    id SERIAL,
    experiment_id VARCHAR(100),
    user_id VARCHAR(100) NOT NULL,
    variant VARCHAR(100) NOT NULL,
    model_name VARCHAR(200) NOT NULL,
    prediction JSONB,
    response_time_ms INTEGER,
    timestamp TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
    session_id VARCHAR(100),
    metadata JSONB
) PARTITION BY RANGE (timestamp);

-- Create monthly partitions
CREATE TABLE experiment_events_2024_01 PARTITION OF experiment_events
    FOR VALUES FROM ('2024-01-01') TO ('2024-02-01');

CREATE TABLE experiment_events_2024_02 PARTITION OF experiment_events
    FOR VALUES FROM ('2024-02-01') TO ('2024-03-01');

-- Add more partitions as needed...
```

### 2.2 MongoDB Collections Design

#### 2.2.1 Document Schemas
```javascript
// User Activity Logs Collection
db.user_activities.createIndex({ "user_id": 1, "timestamp": -1 })
db.user_activities.createIndex({ "activity_type": 1, "timestamp": -1 })

// Sample document structure
{
  "_id": ObjectId("..."),
  "user_id": "user123",
  "session_id": "session_abc",
  "activity_type": "model_prediction",
  "timestamp": ISODate("2024-01-15T10:30:00Z"),
  "details": {
    "model_name": "customer_churn_v2",
    "prediction_result": "high_risk",
    "confidence_score": 0.85,
    "input_features": {
      "customer_age": 35,
      "purchase_frequency": 12,
      "account_balance": 5000
    }
  },
  "metadata": {
    "ip_address": "192.168.1.100",
    "user_agent": "Mozilla/5.0...",
    "response_time_ms": 150
  }
}

// Model Training Logs Collection
db.model_training_logs.createIndex({ "model_name": 1, "version": 1 })
db.model_training_logs.createIndex({ "training_start_time": -1 })

{
  "_id": ObjectId("..."),
  "model_name": "customer_churn",
  "version": "v2.1",
  "training_start_time": ISODate("2024-01-15T08:00:00Z"),
  "training_end_time": ISODate("2024-01-15T10:30:00Z"),
  "training_config": {
    "algorithm": "random_forest",
    "hyperparameters": {
      "n_estimators": 100,
      "max_depth": 10,
      "min_samples_split": 2
    },
    "cross_validation_folds": 5
  },
  "dataset_info": {
    "training_samples": 50000,
    "validation_samples": 10000,
    "test_samples": 10000,
    "feature_count": 25
  },
  "metrics": {
    "accuracy": 0.92,
    "precision": 0.89,
    "recall": 0.94,
    "f1_score": 0.91,
    "auc_roc": 0.96
  },
  "feature_importance": [
    {"feature": "purchase_frequency", "importance": 0.25},
    {"feature": "account_balance", "importance": 0.20},
    {"feature": "customer_age", "importance": 0.15}
  ]
}

// System Configuration Collection
db.system_config.createIndex({ "config_type": 1, "environment": 1 })

{
  "_id": ObjectId("..."),
  "config_type": "ml_model_config",
  "environment": "production",
  "model_name": "customer_churn",
  "config": {
    "auto_retrain": {
      "enabled": true,
      "schedule": "0 2 * * 0", // Weekly at 2 AM Sunday
      "data_drift_threshold": 0.1,
      "performance_threshold": 0.85
    },
    "serving": {
      "max_batch_size": 1000,
      "timeout_ms": 5000,
      "cache_predictions": true,
      "cache_ttl_seconds": 300
    },
    "monitoring": {
      "track_predictions": true,
      "track_performance": true,
      "alert_on_drift": true,
      "alert_thresholds": {
        "accuracy_drop": 0.05,
        "latency_increase": 2.0
      }
    }
  },
  "created_at": ISODate("2024-01-10T00:00:00Z"),
  "updated_at": ISODate("2024-01-15T12:00:00Z"),
  "version": 3
}
```

### 2.3 Redis Caching Strategy

#### 2.3.1 Cache Implementation
```python
# services/cache_service.py
import redis
import json
import pickle
from typing import Any, Optional, Union
from datetime import timedelta
import hashlib

class CacheService:
    def __init__(self, 
                 host: str = 'localhost', 
                 port: int = 6379, 
                 db: int = 0,
                 password: Optional[str] = None):
        self.redis_client = redis.Redis(
            host=host, 
            port=port, 
            db=db, 
            password=password,
            decode_responses=False  # Keep binary for pickle
        )
        
    def _make_key(self, namespace: str, key: str) -> str:
        """Create namespaced cache key"""
        return f"{namespace}:{key}"
    
    def _serialize_value(self, value: Any) -> bytes:
        """Serialize value for storage"""
        if isinstance(value, (dict, list)):
            return json.dumps(value).encode('utf-8')
        elif isinstance(value, str):
            return value.encode('utf-8')
        else:
            return pickle.dumps(value)
    
    def _deserialize_value(self, value: bytes) -> Any:
        """Deserialize value from storage"""
        try:
            # Try JSON first
            return json.loads(value.decode('utf-8'))
        except (json.JSONDecodeError, UnicodeDecodeError):
            try:
                # Try pickle
                return pickle.loads(value)
            except:
                # Return as string
                return value.decode('utf-8', errors='ignore')
    
    async def set(self, 
                 namespace: str, 
                 key: str, 
                 value: Any, 
                 ttl: Optional[Union[int, timedelta]] = None) -> bool:
        """Set cache value with optional TTL"""
        cache_key = self._make_key(namespace, key)
        serialized_value = self._serialize_value(value)
        
        if isinstance(ttl, timedelta):
            ttl = int(ttl.total_seconds())
        
        return self.redis_client.set(cache_key, serialized_value, ex=ttl)
    
    async def get(self, namespace: str, key: str) -> Optional[Any]:
        """Get cache value"""
        cache_key = self._make_key(namespace, key)
        value = self.redis_client.get(cache_key)
        
        if value is None:
            return None
        
        return self._deserialize_value(value)
    
    async def delete(self, namespace: str, key: str) -> bool:
        """Delete cache value"""
        cache_key = self._make_key(namespace, key)
        return bool(self.redis_client.delete(cache_key))
    
    async def exists(self, namespace: str, key: str) -> bool:
        """Check if cache key exists"""
        cache_key = self._make_key(namespace, key)
        return bool(self.redis_client.exists(cache_key))
    
    async def increment(self, namespace: str, key: str, amount: int = 1) -> int:
        """Increment counter"""
        cache_key = self._make_key(namespace, key)
        return self.redis_client.incr(cache_key, amount)
    
    async def set_hash(self, namespace: str, key: str, mapping: dict, ttl: Optional[int] = None):
        """Set hash values"""
        cache_key = self._make_key(namespace, key)
        serialized_mapping = {k: self._serialize_value(v) for k, v in mapping.items()}
        
        pipe = self.redis_client.pipeline()
        pipe.hset(cache_key, mapping=serialized_mapping)
        if ttl:
            pipe.expire(cache_key, ttl)
        pipe.execute()
    
    async def get_hash(self, namespace: str, key: str, field: Optional[str] = None) -> Union[dict, Any]:
        """Get hash values"""
        cache_key = self._make_key(namespace, key)
        
        if field:
            value = self.redis_client.hget(cache_key, field)
            return self._deserialize_value(value) if value else None
        else:
            hash_data = self.redis_client.hgetall(cache_key)
            return {k.decode('utf-8'): self._deserialize_value(v) for k, v in hash_data.items()}

# Cache decorators for common patterns
def cache_prediction(ttl: int = 300):
    """Decorator to cache ML predictions"""
    def decorator(func):
        async def wrapper(*args, **kwargs):
            cache_service = CacheService()
            
            # Create cache key from function arguments
            cache_input = f"{func.__name__}:{args}:{sorted(kwargs.items())}"
            cache_key = hashlib.md5(cache_input.encode()).hexdigest()
            
            # Try to get from cache
            cached_result = await cache_service.get("predictions", cache_key)
            if cached_result is not None:
                return cached_result
            
            # Compute result and cache it
            result = await func(*args, **kwargs)
            await cache_service.set("predictions", cache_key, result, ttl=ttl)
            
            return result
        return wrapper
    return decorator

# Usage example:
@cache_prediction(ttl=600)  # Cache for 10 minutes
async def predict_customer_churn(customer_data: dict):
    # ML prediction logic here
    pass
```

## 3. API Design and Implementation

### 3.1 FastAPI Application Structure

#### 3.1.1 Main Application
```python
# main.py
from fastapi import FastAPI, Request, HTTPException
from fastapi.middleware.cors import CORSMiddleware
from fastapi.middleware.trustedhost import TrustedHostMiddleware
from fastapi.responses import JSONResponse
import time
import logging
from .api import auth, users, analytics, models
from .middleware import AuthMiddleware, RateLimitMiddleware
from .core.config import settings

# Configure logging
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

# Create FastAPI application
app = FastAPI(
    title="Enterprise AI Analytics Platform API",
    description="Comprehensive API for AI-powered analytics platform",
    version="1.0.0",
    docs_url="/docs",
    redoc_url="/redoc"
)

# Add security middleware
app.add_middleware(TrustedHostMiddleware, allowed_hosts=settings.ALLOWED_HOSTS)
app.add_middleware(
    CORSMiddleware,
    allow_origins=settings.CORS_ORIGINS,
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

# Custom middleware
app.add_middleware(AuthMiddleware)
app.add_middleware(RateLimitMiddleware, calls=100, period=60)

# Request logging middleware
@app.middleware("http")
async def log_requests(request: Request, call_next):
    start_time = time.time()
    
    # Log request
    logger.info(f"Request: {request.method} {request.url}")
    
    response = await call_next(request)
    
    # Log response
    process_time = time.time() - start_time
    logger.info(f"Response: {response.status_code} - {process_time:.4f}s")
    
    return response

# Global exception handler
@app.exception_handler(HTTPException)
async def http_exception_handler(request: Request, exc: HTTPException):
    return JSONResponse(
        status_code=exc.status_code,
        content={
            "error": {
                "code": exc.status_code,
                "message": exc.detail,
                "timestamp": time.time()
            }
        }
    )

# Health check endpoint
@app.get("/health")
async def health_check():
    return {
        "status": "healthy",
        "timestamp": time.time(),
        "version": "1.0.0"
    }

# Include API routers
app.include_router(auth.router, prefix="/api/v1")
app.include_router(users.router, prefix="/api/v1")
app.include_router(analytics.router, prefix="/api/v1")
app.include_router(models.router, prefix="/api/v1")

if __name__ == "__main__":
    import uvicorn
    uvicorn.run(
        "main:app",
        host="0.0.0.0",
        port=8000,
        reload=settings.DEBUG,
        workers=settings.WORKERS
    )
```

#### 3.1.2 Analytics API Implementation
```python
# api/analytics.py
from fastapi import APIRouter, Depends, HTTPException, Query, BackgroundTasks
from typing import List, Optional, Dict, Any
from datetime import datetime, timedelta
from ..services.analytics_service import AnalyticsService
from ..services.auth_service import get_current_user
from ..models.user import User
from ..schemas.analytics import (
    AnalyticsQuery, AnalyticsResponse, 
    DashboardConfig, MetricDefinition
)

router = APIRouter(prefix="/analytics", tags=["analytics"])

@router.post("/query", response_model=AnalyticsResponse)
async def execute_analytics_query(
    query: AnalyticsQuery,
    current_user: User = Depends(get_current_user),
    analytics_service: AnalyticsService = Depends()
):
    """Execute analytics query and return results"""
    try:
        # Validate user permissions for data access
        if not analytics_service.check_data_access_permission(current_user, query.data_sources):
            raise HTTPException(status_code=403, detail="Insufficient data access permissions")
        
        # Execute query
        result = await analytics_service.execute_query(query)
        
        return AnalyticsResponse(
            query_id=result.query_id,
            data=result.data,
            metadata=result.metadata,
            execution_time_ms=result.execution_time_ms,
            row_count=result.row_count
        )
        
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Query execution failed: {str(e)}")

@router.get("/dashboards/{dashboard_id}")
async def get_dashboard(
    dashboard_id: str,
    current_user: User = Depends(get_current_user),
    analytics_service: AnalyticsService = Depends()
):
    """Get dashboard configuration and data"""
    dashboard = await analytics_service.get_dashboard(dashboard_id, current_user.id)
    if not dashboard:
        raise HTTPException(status_code=404, detail="Dashboard not found")
    
    return dashboard

@router.post("/dashboards", response_model=Dict[str, Any])
async def create_dashboard(
    dashboard_config: DashboardConfig,
    current_user: User = Depends(get_current_user),
    analytics_service: AnalyticsService = Depends()
):
    """Create new analytics dashboard"""
    dashboard = await analytics_service.create_dashboard(dashboard_config, current_user.id)
    return {"dashboard_id": dashboard.id, "message": "Dashboard created successfully"}

@router.get("/metrics/realtime")
async def get_realtime_metrics(
    metrics: List[str] = Query(..., description="List of metric names"),
    time_range: str = Query("1h", description="Time range (e.g., '1h', '24h', '7d')"),
    current_user: User = Depends(get_current_user),
    analytics_service: AnalyticsService = Depends()
):
    """Get real-time metrics data"""
    try:
        # Parse time range
        end_time = datetime.utcnow()
        if time_range.endswith('h'):
            hours = int(time_range[:-1])
            start_time = end_time - timedelta(hours=hours)
        elif time_range.endswith('d'):
            days = int(time_range[:-1])
            start_time = end_time - timedelta(days=days)
        else:
            raise ValueError("Invalid time range format")
        
        # Get metrics data
        metrics_data = await analytics_service.get_realtime_metrics(
            metrics, start_time, end_time
        )
        
        return {
            "metrics": metrics_data,
            "time_range": {
                "start": start_time.isoformat(),
                "end": end_time.isoformat()
            }
        }
        
    except Exception as e:
        raise HTTPException(status_code=400, detail=f"Failed to fetch metrics: {str(e)}")

@router.post("/export")
async def export_analytics_data(
    query: AnalyticsQuery,
    format: str = Query("csv", regex="^(csv|json|parquet)$"),
    background_tasks: BackgroundTasks,
    current_user: User = Depends(get_current_user),
    analytics_service: AnalyticsService = Depends()
):
    """Export analytics data in specified format"""
    
    # Start background export task
    export_task_id = await analytics_service.start_export_task(
        query, format, current_user.id
    )
    
    background_tasks.add_task(
        analytics_service.process_export_task,
        export_task_id
    )
    
    return {
        "export_task_id": export_task_id,
        "message": "Export task started",
        "estimated_completion": "5-10 minutes"
    }

@router.get("/export/{task_id}/status")
async def get_export_status(
    task_id: str,
    current_user: User = Depends(get_current_user),
    analytics_service: AnalyticsService = Depends()
):
    """Get status of export task"""
    status = await analytics_service.get_export_task_status(task_id, current_user.id)
    if not status:
        raise HTTPException(status_code=404, detail="Export task not found")
    
    return status
```

---

*This Low-Level Design document provides detailed implementation guidance for building the Enterprise AI-Powered Analytics Platform with production-ready code examples and architectural patterns.*
