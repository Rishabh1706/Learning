# Intelligent Document Analyzer Project
*AI-powered document processing and analysis platform using Azure Cognitive Services*

## 🎯 Project Overview

The Intelligent Document Analyzer is a comprehensive AI-powered platform that processes, analyzes, and extracts insights from various document formats. It leverages Azure Cognitive Services, OpenAI, and machine learning to provide intelligent document understanding capabilities.

## 🚀 Key Features

### Core Capabilities
- **Multi-format Document Processing**: PDF, Word, Excel, PowerPoint, images
- **Intelligent Text Extraction**: OCR with layout understanding
- **Content Analysis**: Summarization, key phrase extraction, entity recognition
- **Semantic Search**: Vector-based document search and retrieval
- **Question Answering**: Natural language queries about document content
- **Classification**: Automatic document categorization and tagging
- **Compliance Checking**: Policy and regulation compliance analysis

### Advanced Features
- **Batch Processing**: Handle large document volumes
- **Real-time Processing**: Live document analysis APIs
- **Multi-language Support**: Process documents in multiple languages
- **Custom Models**: Train domain-specific extraction models
- **Audit Trail**: Complete processing history and provenance
- **Integration APIs**: REST APIs for enterprise integration

## 🏗️ System Architecture

### High-Level Architecture

```
┌─────────────────────────────────────────────────────────────────────────────────┐
│                           Document Input Layer                                  │
├─────────────────────────────────────────────────────────────────────────────────┤
│  ┌─────────────────┐  ┌─────────────────┐  ┌─────────────────┐                │
│  │   File Upload   │  │   Email Intake  │  │   API Ingestion │                │
│  │   (Web/Mobile)  │  │   (Automated)   │  │   (Programmatic)│                │
│  └─────────────────┘  └─────────────────┘  └─────────────────┘                │
└─────────────────────────────────────────────────────────────────────────────────┘
                                        │
                                        │ Document Queue
                                        ▼
┌─────────────────────────────────────────────────────────────────────────────────┐
│                        Document Processing Pipeline                             │
├─────────────────────────────────────────────────────────────────────────────────┤
│  ┌─────────────────┐  ┌─────────────────┐  ┌─────────────────┐                │
│  │ Format Detection│  │ Text Extraction │  │ Layout Analysis │                │
│  │ & Validation    │  │ (Azure Form     │  │ & Structure     │                │
│  │                 │  │ Recognizer)     │  │ Recognition     │                │
│  └─────────────────┘  └─────────────────┘  └─────────────────┘                │
│                                        │                                        │
│  ┌─────────────────┐  ┌─────────────────┐  ┌─────────────────┐                │
│  │ Content Cleanup │  │ Language        │  │ Quality         │                │
│  │ & Normalization │  │ Detection       │  │ Assessment      │                │
│  └─────────────────┘  └─────────────────┘  └─────────────────┘                │
└─────────────────────────────────────────────────────────────────────────────────┘
                                        │
                                        │ Processed Content
                                        ▼
┌─────────────────────────────────────────────────────────────────────────────────┐
│                           AI Analysis Layer                                     │
├─────────────────────────────────────────────────────────────────────────────────┤
│  ┌─────────────────┐  ┌─────────────────┐  ┌─────────────────┐                │
│  │ Entity          │  │ Key Phrase      │  │ Sentiment       │                │
│  │ Recognition     │  │ Extraction      │  │ Analysis        │                │
│  │ (Azure Text     │  │ (Azure Text     │  │ (Azure Text     │                │
│  │ Analytics)      │  │ Analytics)      │  │ Analytics)      │                │
│  └─────────────────┘  └─────────────────┘  └─────────────────┘                │
│                                        │                                        │
│  ┌─────────────────┐  ┌─────────────────┐  ┌─────────────────┐                │
│  │ Document        │  │ Content         │  │ Relationship    │                │
│  │ Classification  │  │ Summarization   │  │ Extraction      │                │
│  │ (Custom ML)     │  │ (Azure OpenAI)  │  │ (Custom NLP)    │                │
│  └─────────────────┘  └─────────────────┘  └─────────────────┘                │
└─────────────────────────────────────────────────────────────────────────────────┘
                                        │
                                        │ Analyzed Data
                                        ▼
┌─────────────────────────────────────────────────────────────────────────────────┐
│                        Knowledge Management Layer                               │
├─────────────────────────────────────────────────────────────────────────────────┤
│  ┌─────────────────┐  ┌─────────────────┐  ┌─────────────────┐                │
│  │ Vector          │  │ Knowledge Graph │  │ Search Index    │                │
│  │ Embeddings      │  │ Construction    │  │ (Azure Cognitive│                │
│  │ (Azure OpenAI)  │  │ (Custom Logic)  │  │ Search)         │                │
│  └─────────────────┘  └─────────────────┘  └─────────────────┘                │
│                                        │                                        │
│  ┌─────────────────┐  ┌─────────────────┐  ┌─────────────────┐                │
│  │ Document        │  │ Relationship    │  │ Metadata        │                │
│  │ Clustering      │  │ Mapping         │  │ Enrichment      │                │
│  └─────────────────┘  └─────────────────┘  └─────────────────┘                │
└─────────────────────────────────────────────────────────────────────────────────┘
                                        │
                                        │ Structured Knowledge
                                        ▼
┌─────────────────────────────────────────────────────────────────────────────────┐
│                          Application Layer                                      │
├─────────────────────────────────────────────────────────────────────────────────┤
│  ┌─────────────────┐  ┌─────────────────┐  ┌─────────────────┐                │
│  │ Web Dashboard   │  │ REST APIs       │  │ Mobile App      │                │
│  │ (React)         │  │ (FastAPI)       │  │ (React Native)  │                │
│  └─────────────────┘  └─────────────────┘  └─────────────────┘                │
│                                        │                                        │
│  ┌─────────────────┐  ┌─────────────────┐  ┌─────────────────┐                │
│  │ Admin Portal    │  │ Analytics       │  │ Integration     │                │
│  │ (Management)    │  │ Dashboard       │  │ Webhooks        │                │
│  └─────────────────┘  └─────────────────┘  └─────────────────┘                │
└─────────────────────────────────────────────────────────────────────────────────┘
```

## 🔧 Technology Stack

### AI and Machine Learning
- **Azure Form Recognizer**: Document layout and text extraction
- **Azure Text Analytics**: Entity recognition, key phrases, sentiment
- **Azure OpenAI**: GPT-4 for summarization and Q&A
- **Azure Cognitive Search**: Semantic search and indexing
- **Custom ML Models**: Document classification and domain-specific extraction

### Backend Services
- **FastAPI**: Python web framework for APIs
- **Celery**: Asynchronous task processing
- **Redis**: Caching and task queue
- **PostgreSQL**: Metadata and structured data storage
- **Azure Blob Storage**: Document and file storage

### Frontend Applications
- **React.js**: Web dashboard and admin portal
- **TypeScript**: Type-safe frontend development
- **Tailwind CSS**: Modern UI styling
- **Chart.js**: Data visualization
- **React Query**: State management and caching

### Infrastructure and DevOps
- **Docker**: Containerization
- **Kubernetes**: Container orchestration
- **Azure Container Registry**: Container image storage
- **Azure Monitor**: Application monitoring and logging
- **Terraform**: Infrastructure as Code

## 📊 Core Features Implementation

### 1. Document Processing Pipeline

```python
# Document processing orchestrator
from azure.ai.formrecognizer import DocumentAnalysisClient
from azure.ai.textanalytics import TextAnalyticsClient
import openai
from typing import Dict, List, Any

class DocumentProcessor:
    def __init__(self, config):
        self.form_recognizer = DocumentAnalysisClient(
            endpoint=config.form_recognizer_endpoint,
            credential=AzureKeyCredential(config.form_recognizer_key)
        )
        self.text_analytics = TextAnalyticsClient(
            endpoint=config.text_analytics_endpoint,
            credential=AzureKeyCredential(config.text_analytics_key)
        )
        self.openai_client = openai.Client(
            api_key=config.openai_key,
            base_url=config.openai_endpoint
        )
    
    async def process_document(self, document_url: str, document_type: str = None) -> Dict[str, Any]:
        """Complete document processing pipeline"""
        
        # Step 1: Extract text and layout
        extraction_result = await self.extract_content(document_url, document_type)
        
        # Step 2: Analyze content
        analysis_result = await self.analyze_content(extraction_result['content'])
        
        # Step 3: Generate embeddings
        embeddings = await self.generate_embeddings(extraction_result['content'])
        
        # Step 4: Classify document
        classification = await self.classify_document(extraction_result['content'])
        
        # Step 5: Extract domain-specific information
        domain_data = await self.extract_domain_specific_data(
            extraction_result, document_type
        )
        
        return {
            'document_id': extraction_result['document_id'],
            'content': extraction_result['content'],
            'layout': extraction_result['layout'],
            'entities': analysis_result['entities'],
            'key_phrases': analysis_result['key_phrases'],
            'sentiment': analysis_result['sentiment'],
            'summary': analysis_result['summary'],
            'embeddings': embeddings,
            'classification': classification,
            'domain_data': domain_data,
            'processing_metadata': {
                'processed_at': datetime.utcnow().isoformat(),
                'confidence_scores': analysis_result['confidence_scores'],
                'language': analysis_result['language']
            }
        }
    
    async def extract_content(self, document_url: str, document_type: str) -> Dict:
        """Extract text and layout from document"""
        
        # Determine the best model based on document type
        model_map = {
            'invoice': 'prebuilt-invoice',
            'receipt': 'prebuilt-receipt',
            'business_card': 'prebuilt-businessCard',
            'id_document': 'prebuilt-idDocument',
            'general': 'prebuilt-document'
        }
        
        model_id = model_map.get(document_type, 'prebuilt-document')
        
        # Analyze document
        poller = self.form_recognizer.begin_analyze_document_from_url(
            model_id=model_id,
            document_url=document_url
        )
        result = poller.result()
        
        # Extract content and structure
        content = ""
        layout = []
        tables = []
        
        for page in result.pages:
            # Extract text content
            for line in page.lines:
                content += line.content + "\n"
                layout.append({
                    'text': line.content,
                    'bounding_box': [point for point in line.polygon],
                    'page': page.page_number
                })
        
        # Extract tables
        for table in result.tables:
            table_data = []
            for cell in table.cells:
                table_data.append({
                    'content': cell.content,
                    'row_index': cell.row_index,
                    'column_index': cell.column_index,
                    'confidence': cell.confidence
                })
            tables.append(table_data)
        
        return {
            'document_id': str(uuid.uuid4()),
            'content': content.strip(),
            'layout': layout,
            'tables': tables,
            'page_count': len(result.pages),
            'confidence': result.api_version
        }
    
    async def analyze_content(self, content: str) -> Dict:
        """Analyze content using Azure Text Analytics"""
        
        # Entity recognition
        entities_result = self.text_analytics.recognize_entities([content])
        entities = []
        for entity in entities_result[0].entities:
            entities.append({
                'text': entity.text,
                'category': entity.category,
                'subcategory': entity.subcategory,
                'confidence': entity.confidence_score,
                'offset': entity.offset,
                'length': entity.length
            })
        
        # Key phrase extraction
        key_phrases_result = self.text_analytics.extract_key_phrases([content])
        key_phrases = key_phrases_result[0].key_phrases
        
        # Sentiment analysis
        sentiment_result = self.text_analytics.analyze_sentiment([content])
        sentiment = {
            'overall': sentiment_result[0].sentiment,
            'positive_score': sentiment_result[0].confidence_scores.positive,
            'neutral_score': sentiment_result[0].confidence_scores.neutral,
            'negative_score': sentiment_result[0].confidence_scores.negative
        }
        
        # Language detection
        language_result = self.text_analytics.detect_language([content])
        language = language_result[0].primary_language.iso6391_name
        
        # Generate summary using OpenAI
        summary = await self.generate_summary(content)
        
        return {
            'entities': entities,
            'key_phrases': key_phrases,
            'sentiment': sentiment,
            'language': language,
            'summary': summary,
            'confidence_scores': {
                'entity_avg': sum([e['confidence'] for e in entities]) / len(entities) if entities else 0,
                'language_confidence': language_result[0].primary_language.confidence_score
            }
        }
    
    async def generate_summary(self, content: str) -> str:
        """Generate document summary using OpenAI"""
        
        # Truncate content if too long
        max_tokens = 3000  # Leave room for prompt and response
        if len(content) > max_tokens * 4:  # Rough estimate of 4 chars per token
            content = content[:max_tokens * 4]
        
        prompt = f"""
        Please provide a concise summary of the following document. Focus on:
        1. Main purpose and content type
        2. Key information and data points
        3. Important dates, names, and numbers
        4. Any action items or conclusions
        
        Document content:
        {content}
        
        Summary:
        """
        
        response = self.openai_client.chat.completions.create(
            model="gpt-4",
            messages=[
                {"role": "system", "content": "You are a document analysis expert. Provide clear, concise summaries."},
                {"role": "user", "content": prompt}
            ],
            max_tokens=300,
            temperature=0.3
        )
        
        return response.choices[0].message.content
    
    async def classify_document(self, content: str) -> Dict:
        """Classify document using custom ML model"""
        
        # This would typically use a trained classification model
        # For demo purposes, using rule-based classification
        
        content_lower = content.lower()
        
        # Define document type patterns
        patterns = {
            'invoice': ['invoice', 'bill', 'payment due', 'amount owed'],
            'contract': ['agreement', 'terms and conditions', 'party', 'whereas'],
            'report': ['report', 'analysis', 'findings', 'recommendation'],
            'email': ['from:', 'to:', 'subject:', 'dear'],
            'presentation': ['slide', 'agenda', 'overview', 'conclusion'],
            'legal': ['legal', 'court', 'plaintiff', 'defendant', 'jurisdiction'],
            'financial': ['financial', 'revenue', 'profit', 'loss', 'balance sheet'],
            'technical': ['technical', 'specification', 'system', 'architecture']
        }
        
        scores = {}
        for doc_type, keywords in patterns.items():
            score = sum(1 for keyword in keywords if keyword in content_lower)
            scores[doc_type] = score / len(keywords)  # Normalize by keyword count
        
        # Get top classification
        top_type = max(scores, key=scores.get) if scores else 'general'
        confidence = scores.get(top_type, 0)
        
        return {
            'document_type': top_type,
            'confidence': confidence,
            'all_scores': scores
        }
```

### 2. Semantic Search Implementation

```python
from azure.search.documents import SearchClient
from azure.search.documents.indexes import SearchIndexClient
from azure.search.documents.models import VectorizedQuery
import numpy as np

class SemanticSearchEngine:
    def __init__(self, search_endpoint, search_key, index_name):
        self.search_client = SearchClient(
            endpoint=search_endpoint,
            index_name=index_name,
            credential=AzureKeyCredential(search_key)
        )
        self.index_client = SearchIndexClient(
            endpoint=search_endpoint,
            credential=AzureKeyCredential(search_key)
        )
        self.index_name = index_name
    
    async def create_search_index(self):
        """Create search index with vector support"""
        from azure.search.documents.indexes.models import (
            SearchIndex, SearchField, SearchFieldDataType,
            VectorSearch, VectorSearchProfile, HnswAlgorithmConfiguration
        )
        
        fields = [
            SearchField(name="id", type=SearchFieldDataType.String, key=True),
            SearchField(name="content", type=SearchFieldDataType.String, searchable=True),
            SearchField(name="title", type=SearchFieldDataType.String, searchable=True),
            SearchField(name="document_type", type=SearchFieldDataType.String, filterable=True),
            SearchField(name="entities", type=SearchFieldDataType.Collection(SearchFieldDataType.String), filterable=True),
            SearchField(name="key_phrases", type=SearchFieldDataType.Collection(SearchFieldDataType.String), searchable=True),
            SearchField(name="processed_date", type=SearchFieldDataType.DateTimeOffset, filterable=True, sortable=True),
            SearchField(name="file_path", type=SearchFieldDataType.String),
            SearchField(name="content_vector", type=SearchFieldDataType.Collection(SearchFieldDataType.Single),
                       vector_search_dimensions=1536, vector_search_profile_name="default-profile")
        ]
        
        vector_search = VectorSearch(
            profiles=[VectorSearchProfile(name="default-profile", algorithm_configuration_name="default-algorithm")],
            algorithms=[HnswAlgorithmConfiguration(name="default-algorithm")]
        )
        
        index = SearchIndex(name=self.index_name, fields=fields, vector_search=vector_search)
        self.index_client.create_or_update_index(index)
    
    async def index_document(self, processed_document: Dict):
        """Index processed document"""
        
        search_document = {
            'id': processed_document['document_id'],
            'content': processed_document['content'],
            'title': processed_document.get('title', 'Untitled Document'),
            'document_type': processed_document['classification']['document_type'],
            'entities': [entity['text'] for entity in processed_document['entities']],
            'key_phrases': processed_document['key_phrases'],
            'processed_date': processed_document['processing_metadata']['processed_at'],
            'file_path': processed_document.get('file_path', ''),
            'content_vector': processed_document['embeddings']
        }
        
        result = self.search_client.upload_documents([search_document])
        return result
    
    async def hybrid_search(self, query: str, filters: Dict = None, top_k: int = 10) -> List[Dict]:
        """Perform hybrid search (semantic + keyword)"""
        
        # Generate query embedding
        query_embedding = await self.generate_query_embedding(query)
        
        # Create vector query
        vector_query = VectorizedQuery(
            vector=query_embedding,
            k_nearest_neighbors=top_k,
            fields="content_vector"
        )
        
        # Build filter string
        filter_expression = None
        if filters:
            filter_parts = []
            if filters.get('document_type'):
                filter_parts.append(f"document_type eq '{filters['document_type']}'")
            if filters.get('date_from'):
                filter_parts.append(f"processed_date ge {filters['date_from']}")
            if filters.get('date_to'):
                filter_parts.append(f"processed_date le {filters['date_to']}")
            
            if filter_parts:
                filter_expression = " and ".join(filter_parts)
        
        # Perform search
        results = self.search_client.search(
            search_text=query,
            vector_queries=[vector_query],
            filter=filter_expression,
            select=["id", "content", "title", "document_type", "entities", "key_phrases", "file_path"],
            top=top_k,
            include_total_count=True
        )
        
        formatted_results = []
        for result in results:
            formatted_results.append({
                "id": result["id"],
                "title": result["title"],
                "content": result["content"][:500] + "..." if len(result["content"]) > 500 else result["content"],
                "document_type": result["document_type"],
                "entities": result["entities"],
                "key_phrases": result["key_phrases"],
                "file_path": result["file_path"],
                "score": result["@search.score"],
                "relevance": result.get("@search.reranker_score", result["@search.score"])
            })
        
        return formatted_results
    
    async def generate_query_embedding(self, query: str) -> List[float]:
        """Generate embedding for search query"""
        # This would use the same embedding model as document processing
        # Implementation depends on your embedding service
        pass
```

### 3. Question Answering System

```python
class DocumentQASystem:
    def __init__(self, search_engine, openai_client):
        self.search_engine = search_engine
        self.openai_client = openai_client
        self.conversation_memory = {}
    
    async def answer_question(self, question: str, user_id: str = None, filters: Dict = None) -> Dict:
        """Answer questions about documents"""
        
        # Retrieve relevant documents
        search_results = await self.search_engine.hybrid_search(
            query=question,
            filters=filters,
            top_k=5
        )
        
        if not search_results:
            return {
                "answer": "I couldn't find any relevant documents to answer your question.",
                "sources": [],
                "confidence": 0.0
            }
        
        # Build context from search results
        context_parts = []
        sources = []
        
        for i, result in enumerate(search_results):
            context_parts.append(f"Document {i+1} ({result['title']}):\n{result['content']}")
            sources.append({
                "title": result['title'],
                "document_type": result['document_type'],
                "file_path": result['file_path'],
                "relevance_score": result['score']
            })
        
        context = "\n\n".join(context_parts)
        
        # Get conversation history if available
        conversation_history = self.conversation_memory.get(user_id, []) if user_id else []
        
        # Build messages for OpenAI
        messages = [
            {
                "role": "system",
                "content": """You are an intelligent document analysis assistant. Answer questions based on the provided document context.
                
                Guidelines:
                1. Base your answers primarily on the provided documents
                2. If information is not in the documents, clearly state this
                3. Cite specific documents when referencing information
                4. Provide concise but comprehensive answers
                5. If asked about previous parts of the conversation, use the conversation history
                """
            }
        ]
        
        # Add conversation history (last 3 exchanges)
        if conversation_history:
            messages.extend(conversation_history[-6:])
        
        # Add current question with context
        messages.append({
            "role": "user",
            "content": f"""Context from relevant documents:
{context}

Question: {question}"""
        })
        
        # Generate answer
        response = self.openai_client.chat.completions.create(
            model="gpt-4",
            messages=messages,
            max_tokens=500,
            temperature=0.1
        )
        
        answer = response.choices[0].message.content
        
        # Calculate confidence based on search scores and response quality
        avg_relevance = sum(source["relevance_score"] for source in sources) / len(sources)
        confidence = min(avg_relevance * 0.8, 0.95)  # Cap at 95%
        
        # Update conversation memory
        if user_id:
            if user_id not in self.conversation_memory:
                self.conversation_memory[user_id] = []
            
            self.conversation_memory[user_id].extend([
                {"role": "user", "content": question},
                {"role": "assistant", "content": answer}
            ])
            
            # Keep only last 10 exchanges
            if len(self.conversation_memory[user_id]) > 20:
                self.conversation_memory[user_id] = self.conversation_memory[user_id][-20:]
        
        return {
            "answer": answer,
            "sources": sources,
            "confidence": confidence,
            "query": question,
            "context_used": len(search_results) > 0
        }
    
    async def summarize_documents(self, document_ids: List[str]) -> Dict:
        """Generate summary of multiple documents"""
        
        # Retrieve documents
        documents = []
        for doc_id in document_ids:
            # This would fetch from your document store
            doc = await self.get_document_by_id(doc_id)
            if doc:
                documents.append(doc)
        
        if not documents:
            return {"summary": "No documents found.", "document_count": 0}
        
        # Combine content
        combined_content = "\n\n---\n\n".join([
            f"Document: {doc['title']}\nContent: {doc['content']}"
            for doc in documents
        ])
        
        # Generate summary
        messages = [
            {
                "role": "system",
                "content": "You are a document summarization expert. Create comprehensive summaries that capture key information from multiple documents."
            },
            {
                "role": "user",
                "content": f"""Please create a comprehensive summary of the following documents. Include:
1. Main themes and topics
2. Key findings or information
3. Important dates, names, and numbers
4. Any contradictions or relationships between documents

Documents:
{combined_content}"""
            }
        ]
        
        response = self.openai_client.chat.completions.create(
            model="gpt-4",
            messages=messages,
            max_tokens=800,
            temperature=0.2
        )
        
        return {
            "summary": response.choices[0].message.content,
            "document_count": len(documents),
            "documents": [{"id": doc["id"], "title": doc["title"]} for doc in documents]
        }
```

## 📊 Business Impact and Use Cases

### Industry Applications

#### Legal Industry
- **Contract Analysis**: Automated contract review and risk identification
- **Legal Research**: Case law search and precedent analysis
- **Compliance Monitoring**: Regulatory compliance checking
- **Document Discovery**: E-discovery and litigation support

#### Healthcare
- **Medical Records Analysis**: Patient history and treatment extraction
- **Clinical Trial Documentation**: Research document processing
- **Insurance Claims**: Automated claims processing and validation
- **Regulatory Compliance**: FDA and HIPAA compliance checking

#### Financial Services
- **Loan Documentation**: Application processing and risk assessment
- **Regulatory Reporting**: Automated report generation and compliance
- **Research Analysis**: Financial research document analysis
- **Audit Support**: Document review and audit trail creation

#### Government
- **Public Records Processing**: Citizen request processing
- **Regulatory Analysis**: Policy document analysis
- **Freedom of Information**: FOIA request processing
- **Compliance Monitoring**: Regulatory compliance tracking

## 📈 Success Metrics and KPIs

### Technical Metrics
- **Processing Accuracy**: >95% OCR accuracy, >90% entity extraction accuracy
- **Processing Speed**: <30 seconds per document, 1000+ documents/hour batch
- **Search Relevance**: >85% user satisfaction with search results
- **API Performance**: <2 seconds response time for Q&A, <500ms for search

### Business Metrics
- **Cost Reduction**: 70% reduction in manual document processing time
- **Productivity Gain**: 50% faster information retrieval
- **Accuracy Improvement**: 80% reduction in manual processing errors
- **User Adoption**: 90% user satisfaction score, 80% daily active usage

This project demonstrates advanced AI/ML capabilities while solving real business problems and providing measurable value to organizations.
