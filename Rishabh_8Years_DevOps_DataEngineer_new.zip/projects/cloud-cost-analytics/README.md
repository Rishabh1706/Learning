# Cloud Cost Analytics Project

## Project Overview
Built Power BI dashboards with anomaly detection models to track and predict cloud spend across multiple AWS accounts and services.

## Business Problem
- **Current State**: Limited visibility into cloud spending patterns
- **Challenges**:
  - Unexpected cost spikes and budget overruns
  - Lack of cost attribution to business units
  - Manual cost analysis and reporting
  - Reactive cost management approach
- **Impact**: Budget overruns, inefficient resource utilization, poor cost visibility

## Solution Architecture
Comprehensive cost analytics platform with predictive capabilities using Power BI and machine learning.

### Key Components
1. **Data Collection**: AWS Cost and Usage Reports
2. **Data Processing**: Azure Data Factory ETL pipelines
3. **Analytics**: Power BI with embedded ML models
4. **Alerting**: Proactive anomaly detection and notifications
5. **Automation**: Cost optimization recommendations

## Success Metrics
- **Cost Savings**: 25% reduction in overall cloud spend
- **Visibility**: 100% cost attribution to business units
- **Efficiency**: 90% reduction in manual reporting time
- **Accuracy**: 95% cost prediction accuracy
- **Adoption**: Organization-wide cost awareness program
