# 🎯 System Design Mastery: 14 Real-World Case Studies

> **From Zero to System Design Expert: Learning Through Giants' Solutions**

This comprehensive guide breaks down 14 legendary system design case studies from the world's most successful tech companies. Each case study is explained in simple terms, progressing from basic concepts to advanced architecture patterns.

## 📚 Table of Contents

1. [Google Ads & Spanner Database](#1-google-ads--spanner-database)
2. [Meta's Cache Consistency](#2-metas-cache-consistency)
3. [Slack System Design](#3-slack-system-design)
4. [Uber's Driver Location Service](#4-ubers-driver-location-service)
5. [Scaling to 10 Million Users on AWS](#5-scaling-to-10-million-users-on-aws)
6. [Cloudflare's PostgreSQL Architecture](#6-cloudflares-postgresql-architecture)
7. [Gaming Leaderboard Architecture](#7-gaming-leaderboard-architecture)
8. [Scalable Counter Architecture](#8-scalable-counter-architecture)
9. [YouTube & MySQL at Scale](#9-youtube--mysql-at-scale)
10. [Stripe's Idempotent API](#10-stripes-idempotent-api)
11. [Tinder's Scaling Journey](#11-tinders-scaling-journey)
12. [URL Shortener System Design](#12-url-shortener-system-design)
13. [Amazon S3's Durability](#13-amazon-s3s-durability)
14. [Redis Use Cases](#14-redis-use-cases)

---

## 🏗️ System Design Fundamentals

Before diving into case studies, let's understand the key concepts:

### **Basic Terminology**
- **Scalability**: System's ability to handle increased load
- **Availability**: System uptime (99.9% = 8.76 hours downtime/year)
- **Consistency**: All nodes see the same data simultaneously
- **Latency**: Time to process a single request
- **Throughput**: Number of requests processed per second
- **Redundancy**: Having backup systems/data
- **Load Balancing**: Distributing requests across multiple servers

### **Common Architecture Patterns**
- **Vertical Scaling**: Adding more power (CPU, RAM) to existing servers
- **Horizontal Scaling**: Adding more servers to the system
- **Sharding**: Splitting database across multiple servers
- **Replication**: Copying data across multiple servers
- **Caching**: Storing frequently accessed data in fast memory
- **Microservices**: Breaking application into small, independent services

---

## 1. Google Ads & Spanner Database

### **The Problem: From Million to Billion Users** 🚀

**Background**: Google started with a simple university project that became a search engine. As they grew to 4.77 billion users, their advertising system (main revenue source) faced massive scaling challenges.

**Initial Setup**: 
- Used MySQL for simplicity and reliability
- As users grew, they partitioned (split) MySQL databases
- Revenue in 2023: $237 billion from ads

### **The Challenges**

#### **1. Scalability Issues**
- **Problem**: Storage needs exploded with growth
- **Why It Matters**: Re-partitioning MySQL requires moving data between servers
- **Impact**: Caused downtime during critical business operations

#### **2. Transaction Complexity**
- **Problem**: ACID compliance needed for financial data
- **Why ACID Matters**: 
  - **A**tomicity: All operations succeed or fail together
  - **C**onsistency: Data remains valid after transactions
  - **I**solation: Concurrent transactions don't interfere
  - **D**urability: Completed transactions survive system failures
- **Impact**: Difficult to maintain across multiple partitioned databases

### **The Solution: Google Spanner**

Spanner is a globally distributed SQL database that gives the scalability of NoSQL with the ACID properties of traditional SQL databases.

#### **1. Atomicity with Two-Phase Commit**
```
Phase 1 (Prepare): 
  Coordinator → All Partitions: "Ready to commit?"
  All Partitions → Coordinator: "Yes/No"

Phase 2 (Commit):
  If all say "Yes": Coordinator → All: "Commit now!"
  If any say "No": Coordinator → All: "Abort transaction!"
```

**Key Insight**: This ensures all-or-nothing transactions across multiple servers worldwide.

#### **2. Global Consistency with TrueTime**
- **Challenge**: Different servers have different clocks
- **Solution**: TrueTime combines GPS receivers and atomic clocks
- **Process**:
  1. Each data center gets accurate time from TrueTime
  2. Servers sync every 30 seconds
  3. Reads compare timestamps to ensure latest data
  4. System waits if data is outdated

**Real-World Example**: If a user updates their ad budget in Europe, someone viewing it in Asia sees the updated amount immediately.

#### **3. Isolation with Two-Phase Locking**
- **Writes**: Use two-phase locking (acquire all locks, then release all)
- **Reads**: Use snapshot isolation (see data as it was at a specific time)
- **Benefit**: No conflicts between concurrent operations

#### **4. Durability with Paxos**
- **Process**: Write to majority of replicas before confirming success
- **Storage**: Separate compute and storage layers using Google Colossus
- **Result**: 99.999% availability (4.3 minutes downtime per year)

### **Key Lessons**
1. **Start Simple**: Google started with MySQL, not a complex distributed system
2. **Scale Gradually**: They added complexity only when needed
3. **Global Consistency**: Critical for financial applications
4. **Separation of Concerns**: Separate compute and storage for better scalability

---

## 2. Meta's Cache Consistency

### **The Problem: 99.99999999% Cache Accuracy** 🎯

**Background**: Meta (Facebook) serves billions of users with extremely low latency requirements. Cache inconsistency could show users outdated information, affecting user experience.

**Challenge**: When data changes in the database, how do you ensure all caches worldwide reflect the change immediately?

### **The Solution: Multi-Layer Cache Strategy**

#### **1. Cache-Aside Pattern**
```
Read Process:
1. Check cache first
2. If hit: return cached data
3. If miss: read from database, update cache

Write Process:
1. Update database
2. Invalidate cache entry
3. Next read will refresh cache
```

#### **2. Write-Through Cache**
```
Write Process:
1. Write to cache
2. Simultaneously write to database
3. Both must succeed for operation to complete
```

#### **3. Cache Invalidation Strategy**
- **Time-based**: Cache expires after set duration
- **Event-based**: Database changes trigger cache updates
- **Version-based**: Each cache entry has version number

### **Key Techniques**
1. **Geographic Distribution**: Caches in multiple regions
2. **Layered Caching**: L1 (local), L2 (regional), L3 (global)
3. **Async Replication**: Database changes propagate to caches asynchronously
4. **Circuit Breakers**: Fallback to database if cache fails

### **Real-World Impact**
- **User Experience**: No outdated posts or friend updates
- **Performance**: Sub-millisecond response times
- **Cost Savings**: Reduces database load by 90%+

---

## 3. Slack System Design

### **The Problem: Real-Time Messaging at Scale** 💬

**Background**: Slack needs to deliver messages instantly to millions of users across thousands of workspaces while maintaining message ordering and delivery guarantees.

### **The Architecture**

#### **1. Gateway Layer**
- **WebSocket Connections**: Maintain persistent connections with clients
- **Load Balancing**: Distribute connections across multiple servers
- **Authentication**: Verify user permissions for workspaces/channels

#### **2. Message Processing**
```
Message Flow:
1. User sends message via WebSocket
2. Gateway validates and forwards to Message Service
3. Message Service stores in database
4. Fanout Service delivers to all channel members
5. Push notifications sent to offline users
```

#### **3. Data Storage Strategy**
- **Hot Data**: Recent messages in fast cache (Redis)
- **Warm Data**: Recent months in primary database (MySQL)
- **Cold Data**: Old messages in archived storage (S3)

#### **4. Real-Time Delivery**
- **Online Users**: Direct WebSocket delivery
- **Offline Users**: Push notifications + message queuing
- **Message Ordering**: Sequence numbers ensure correct order

### **Scaling Techniques**
1. **Horizontal Partitioning**: Split workspaces across servers
2. **Message Queuing**: Buffer messages during high traffic
3. **CDN**: Static assets served from edge locations
4. **Database Sharding**: Partition by workspace ID

---

## 4. Uber's Driver Location Service

### **The Problem: 1 Million Location Updates per Second** 🚗

**Background**: Uber needs to track millions of drivers in real-time and quickly find nearby drivers for ride requests.

### **The Architecture**

#### **1. Location Ingestion**
```
Driver App → Location Service → Processing Pipeline
- GPS coordinates every 4 seconds
- Data validation and filtering
- Batch processing for efficiency
```

#### **2. Geospatial Indexing**
- **Geohashing**: Convert lat/lng to hash strings
- **QuadTree**: Divide map into recursive quadrants
- **S2 Geometry**: Google's spatial indexing system

**Example**: San Francisco divided into grid cells, each containing drivers

#### **3. Matching Algorithm**
```
Ride Request Process:
1. Passenger requests ride
2. Find nearby grid cells
3. Query drivers in those cells
4. Rank by distance, rating, ETA
5. Send requests to top drivers
6. First to accept gets the ride
```

#### **4. Real-Time Updates**
- **Supply/Demand**: Adjust pricing based on driver availability
- **ETA Calculation**: Machine learning predicts arrival times
- **Route Optimization**: Find fastest path considering traffic

### **Technical Innovations**
1. **Microservices**: Separate services for location, matching, pricing
2. **Event-Driven**: Use Kafka for real-time event processing
3. **Caching**: Redis for frequently accessed driver locations
4. **Machine Learning**: Predict demand patterns and optimize positioning

---

## 5. Scaling to 10 Million Users on AWS

### **The Journey: From 0 to 10 Million Users** 📈

This case study shows the typical evolution of a web application as it scales from a startup to a major platform.

#### **Stage 1: Pre-Launch (Static Site)**
- **AWS Amplify**: Host static landing page
- **AWS Lambda**: Serverless backend functions
- **Cost**: Near zero operational costs

#### **Stage 2: Launch (Single Server)**
- **Single EC2 Instance**: Database + backend + frontend
- **Elastic IP**: Static IP address
- **Route 53**: DNS management
- **Vertical Scaling**: Upgrade to larger instance types

#### **Stage 3: 10 Users (Separation of Concerns)**
- **Separate EC2 Instances**: Backend and database on different servers
- **SQL Database**: Reliable and well-supported
- **Larger Database Instance**: Handle growing data

#### **Stage 4: 1,000 Users (High Availability)**
- **Multi-AZ Deployment**: Servers in multiple availability zones
- **Leader-Follower Database**: Write to leader, read from followers
- **Elastic Load Balancer**: Distribute traffic with health checks
- **Auto-Failover**: Automatic recovery from failures

#### **Stage 5: 10,000 Users (Performance Optimization)**
- **Stateless Backend**: Move session data to ElastiCache
- **Horizontal Scaling**: Add more servers behind load balancer
- **Database Read Replicas**: Multiple followers for read scaling
- **Caching Layer**: ElastiCache (Redis/Memcached) for database reads
- **CDN**: CloudFront for static content (CSS, JS, images)
- **Auto Scaling**: CloudWatch triggers based on CPU/memory usage

#### **Stage 6: 500,000 Users (Microservices)**
- **Service Decomposition**: Break monolith into microservices
- **Multi-Layer Load Balancing**: Load balancers between each layer
- **NoSQL Database**: DynamoDB for session and user data
- **Infrastructure as Code**: CloudFormation templates
- **99.99% SLA**: Less than 52 minutes downtime per year

#### **Stage 7: 10 Million Users (Global Scale)**
- **Database Federation**: Split by business domain (users, products, orders)
- **Database Sharding**: Split single tables across multiple databases
- **NoSQL Migration**: Move appropriate data to NoSQL databases
- **Multi-Region**: Deploy across multiple AWS regions
- **Cross-Region Replication**: Data replication for disaster recovery

### **Key AWS Services Used**
1. **Compute**: EC2, Lambda, ECS
2. **Storage**: S3, EBS, EFS
3. **Database**: RDS, DynamoDB, ElastiCache
4. **Networking**: VPC, ELB, CloudFront, Route 53
5. **Monitoring**: CloudWatch, X-Ray
6. **Management**: CloudFormation, Systems Manager

### **Scaling Principles**
1. **Start Simple**: Don't over-engineer early
2. **Scale Gradually**: Add complexity as needed
3. **Monitor Everything**: Use metrics to guide decisions
4. **Automate Operations**: Reduce manual intervention
5. **Plan for Failure**: Design for resilience

---

## 6. Cloudflare's PostgreSQL Architecture

### **The Problem: 55 Million Requests per Second** ⚡

**Background**: Cloudflare handles massive global traffic and needs to serve configuration data for millions of websites with extremely low latency.

### **The Architecture**

#### **1. Distributed PostgreSQL Clusters**
- **15 PostgreSQL Clusters**: Geographically distributed
- **Read Replicas**: Multiple read-only copies per region
- **Connection Pooling**: PgBouncer to manage connections efficiently
- **Async Replication**: Near real-time data synchronization

#### **2. Caching Strategy**
```
Multi-Layer Caching:
1. Application Cache: In-memory for hottest data
2. Redis Cache: Shared cache for database queries
3. CDN Edge Cache: Cached responses at edge locations
4. Database Query Cache: PostgreSQL internal caching
```

#### **3. Query Optimization**
- **Prepared Statements**: Pre-compiled queries for better performance
- **Index Optimization**: Carefully designed indexes for common queries
- **Query Planning**: PostgreSQL query optimizer with statistics
- **Partitioning**: Split large tables by time or geography

#### **4. High Availability**
- **Streaming Replication**: Continuous log shipping
- **Automatic Failover**: Promote replica if primary fails
- **Cross-Region Backup**: Data replicated to multiple regions
- **Point-in-Time Recovery**: Restore to any moment in time

### **Performance Optimizations**
1. **Connection Pooling**: Reduce overhead of connection creation
2. **Batch Operations**: Group multiple operations together
3. **Asynchronous Processing**: Non-blocking operations where possible
4. **Hardware Optimization**: SSD storage, high-memory instances

---

## 7. Gaming Leaderboard Architecture

### **The Problem: Real-Time Rankings for Millions** 🏆

**Background**: Gaming platforms need to maintain real-time leaderboards for millions of players across multiple game modes and time periods.

### **The Architecture**

#### **1. Score Ingestion**
```
Game Client → API Gateway → Score Service → Database
- Validate score authenticity
- Check for cheating/anomalies
- Rate limiting per player
- Batch processing for efficiency
```

#### **2. Data Structure: Redis Sorted Sets**
```
ZADD leaderboard score player_id
ZREVRANGE leaderboard 0 9  // Top 10 players
ZREVRANK leaderboard player_id  // Player's rank
ZSCORE leaderboard player_id  // Player's score
```

#### **3. Multiple Leaderboards**
- **Global**: All players worldwide
- **Regional**: Players by geographic region
- **Friends**: Player's social network
- **Time-based**: Daily, weekly, monthly, all-time

#### **4. Real-Time Updates**
- **WebSocket Connections**: Push rank changes to active players
- **Event Streaming**: Kafka for score update events
- **Caching**: Hot leaderboards in memory
- **Lazy Computation**: Calculate expensive rankings on-demand

### **Scaling Techniques**
1. **Partitioning**: Split by game mode or region
2. **Materialized Views**: Pre-computed rankings for common queries
3. **Approximation**: Use HyperLogLog for very large datasets
4. **Caching**: Multiple cache layers for different access patterns

---

## 8. Scalable Counter Architecture

### **The Problem: Accurate Counting at Scale** 📊

**Background**: Systems like YouTube (video views), Twitter (likes/retweets), and Facebook (reactions) need to count billions of events accurately while maintaining high performance.

### **The Challenges**

#### **1. Race Conditions**
- **Problem**: Multiple updates to same counter simultaneously
- **Impact**: Lost increments, inaccurate counts
- **Example**: 1000 simultaneous "likes" might only increment counter by 500

#### **2. Hot Partitions**
- **Problem**: Popular content creates hotspots
- **Impact**: Database bottlenecks, slow responses
- **Example**: Viral video getting millions of views in minutes

### **The Solutions**

#### **1. Sharded Counters**
```
Original: counter = 1000
Sharded:  shard_1 = 300, shard_2 = 250, shard_3 = 450
Total = sum(all_shards) = 1000

Increment Process:
1. Hash(item_id) → determine shard
2. Increment shard counter
3. Periodically aggregate all shards
```

#### **2. Buffering and Batching**
```
Real-time Flow:
1. Increment → Buffer (Redis/Kafka)
2. Batch processor reads buffer every N seconds
3. Apply batched updates to database
4. Update cache with new totals
```

#### **3. Approximate Counting**
- **HyperLogLog**: Estimate unique count with small memory
- **Count-Min Sketch**: Estimate frequency with probabilistic accuracy
- **Bloom Filters**: Check if event already counted

#### **4. Eventual Consistency**
```
Multi-Layer Approach:
1. Immediate: Show cached/estimated count
2. Near Real-time: Update from buffer every few seconds
3. Batch: Reconcile exact count periodically
4. Analytics: Store historical data for reporting
```

### **Implementation Example: YouTube View Counter**
```
Video View Flow:
1. User watches video → Event logged
2. Real-time: Increment cached counter (Redis)
3. Background: Batch updates to main database
4. Display: Show real-time count from cache
5. Analytics: Store detailed view data for insights
```

---

## 9. YouTube & MySQL at Scale

### **The Problem: 2.49 Billion Users with SQL Database** 📺

**Background**: YouTube started as a simple video-sharing site and grew to become the world's second most visited website while maintaining MySQL as their primary database.

### **The Challenges with Traditional MySQL**

#### **1. Replication Limitations**
- **Single-threaded**: MySQL replication couldn't keep up with writes
- **Lag**: Followers fell behind during high write operations
- **Scalability**: Limited by master server capacity

#### **2. Sharding Complexity**
- **Cross-shard Transactions**: Difficult to maintain ACID properties
- **Application Logic**: Code must know which shard to query
- **Rebalancing**: Moving data between shards causes downtime

#### **3. Performance Issues**
- **Stale Reads**: Reading from followers might return outdated data
- **Connection Overhead**: Too many connections could crash database
- **Query Protection**: No built-in protection against expensive queries

### **The Solution: Vitess Architecture**

Vitess is an open-source database clustering system that makes MySQL horizontally scalable.

#### **1. VTTablet (Sidecar Server)**
```
VTTablet sits between application and MySQL:
- Controls MySQL server lifecycle
- Manages database backups automatically
- Rewrites expensive queries (adds LIMIT clauses)
- Caches frequently accessed data
- Prevents thundering herd problems
```

#### **2. VTGate (Query Router)**
```
VTGate acts as MySQL proxy:
- Routes queries to correct shard automatically
- Maintains connection pools to reduce overhead
- Speaks MySQL protocol (looks like single MySQL)
- Limits concurrent transactions for performance
- Handles cross-shard queries and transactions
```

#### **3. Topology Service (ZooKeeper)**
```
Stores metadata about:
- Schema definitions
- Sharding schemes and key ranges
- Leader/follower relationships
- Server health and status
```

### **How Vitess Works**

#### **Query Flow Example**
```
1. Application sends: SELECT * FROM videos WHERE user_id = 123
2. VTGate determines shard based on user_id
3. VTGate routes to appropriate VTTablet
4. VTTablet executes query on local MySQL
5. Results returned through same path
```

#### **Sharding Made Simple**
```
Original Table: videos (100M rows)
Sharded Tables: 
  - videos_shard_0 (user_id 0-24999999)
  - videos_shard_1 (user_id 25000000-49999999)
  - videos_shard_2 (user_id 50000000-74999999)
  - videos_shard_3 (user_id 75000000-99999999)
```

### **Key Benefits**
1. **Transparent Sharding**: Application doesn't need to know about shards
2. **Connection Pooling**: Reduces MySQL connection overhead
3. **Query Protection**: Automatically limits expensive operations
4. **Operational Simplicity**: Automated backup, failover, resharding
5. **MySQL Compatibility**: Works with existing MySQL applications

### **Real-World Results**
- **2.49 billion users** served successfully
- **Open Source**: Available for other companies to use
- **Multi-Database**: Supports MySQL and MariaDB
- **Proven Scale**: Handles YouTube's massive traffic

---

## 10. Stripe's Idempotent API

### **The Problem: Preventing Double Payments** 💳

**Background**: Payment systems must guarantee that duplicate requests don't result in multiple charges. Network issues, user errors, or system retries could cause the same payment to be processed multiple times.

### **What is Idempotency?**

**Definition**: An idempotent operation produces the same result no matter how many times it's executed.

**Examples**:
- ✅ Idempotent: `SET user_balance = 100`
- ❌ Not Idempotent: `user_balance = user_balance + 10`

### **The Solution: Idempotency Keys**

#### **1. How It Works**
```
API Request with Idempotency Key:
POST /charges
Headers: 
  Idempotency-Key: unique_key_12345
Body:
  amount: 2000
  currency: usd
  customer: cus_12345
```

#### **2. Processing Logic**
```
1. Extract idempotency key from request
2. Check if key exists in database
3. If exists: Return cached response (no new charge)
4. If new: Process payment and store result with key
5. Return response and cache it for future requests
```

#### **3. Database Schema**
```sql
CREATE TABLE idempotency_keys (
  key VARCHAR(255) PRIMARY KEY,
  request_hash VARCHAR(255),
  response_data JSON,
  status ENUM('pending', 'completed', 'failed'),
  created_at TIMESTAMP,
  expires_at TIMESTAMP
);
```

### **Implementation Details**

#### **1. Request Validation**
```
Validation Steps:
1. Idempotency key format check
2. Request body hash comparison
3. Key expiration check (24 hours)
4. Same key with different request body → Error
```

#### **2. Race Condition Handling**
```
Concurrent Requests with Same Key:
1. First request: Creates database record with 'pending' status
2. Subsequent requests: Wait or return "processing" response
3. First request completes: Updates status to 'completed'
4. Subsequent requests: Return cached completed response
```

#### **3. Error Handling**
```
If Original Request Failed:
1. Key marked as 'failed' in database
2. Same key used again → Retry the operation
3. Different outcome possible on retry
4. Success → Update key status to 'completed'
```

### **Best Practices**
1. **Unique Keys**: Use UUIDs or timestamp-based identifiers
2. **Request Hashing**: Ensure same key used for identical requests only
3. **Expiration**: Clean up old keys (typically 24 hours)
4. **Status Tracking**: Track request processing status
5. **Client Retry**: Implement exponential backoff for retries

### **Real-World Benefits**
- **No Double Charges**: Customers never charged twice
- **Reliable Retries**: Safe to retry failed requests
- **Better UX**: Users can safely click "Pay" multiple times
- **System Resilience**: Handles network failures gracefully

---

## 11. Tinder's Scaling Journey

### **The Problem: 1.6 Billion Swipes per Day** ❤️

**Background**: Tinder revolutionized online dating with its swipe mechanic, but scaling to handle billions of daily interactions required innovative solutions.

### **The Architecture Evolution**

#### **1. Core Matching Engine**
```
Swipe Processing:
1. User swipes on profile
2. Record swipe in database (like/pass)
3. Check if other user also liked (mutual match)
4. If match: Create conversation thread
5. Send push notifications to both users
```

#### **2. Profile Discovery Algorithm**
```
Recommendation System:
1. Location-based filtering (primary factor)
2. Age preferences
3. Mutual friends/interests
4. Activity patterns and engagement
5. Machine learning scoring
```

#### **3. Data Architecture**
- **User Profiles**: Cached in Redis for fast access
- **Swipe History**: Time-series data in specialized storage
- **Matches**: Relational database for consistency
- **Messages**: Separate messaging service
- **Images**: CDN for global distribution

### **Scaling Challenges & Solutions**

#### **1. Geographic Scaling**
```
Problem: Users want to see people nearby
Solution: Geosharding
- Partition users by geographic location
- Route requests to nearest data center
- Replicate popular profiles across regions
```

#### **2. Real-Time Matching**
```
Problem: Instant match notifications
Solution: Event-driven architecture
- Kafka for real-time event streaming
- WebSocket connections for active users
- Push notification service for offline users
```

#### **3. Image Processing**
```
Problem: Fast loading of profile photos
Solution: Multi-tier caching
- Thumbnail generation on upload
- CDN distribution globally
- Progressive image loading
- Lazy loading for performance
```

#### **4. Recommendation Performance**
```
Problem: Finding compatible profiles quickly
Solution: Pre-computation
- Nightly batch jobs to generate recommendations
- Cache potential matches for each user
- Real-time filtering based on current preferences
```

### **Technical Innovations**
1. **Microservices**: Separate services for profiles, matching, messaging
2. **Caching Strategy**: Multi-layer caching for different data types
3. **Machine Learning**: Continuous improvement of match quality
4. **A/B Testing**: Constant experimentation with algorithms

---

## 12. URL Shortener System Design

### **The Problem: Shortening URLs at Scale** 🔗

**Background**: Services like bit.ly, tinyurl.com, and Twitter's t.co need to convert long URLs into short ones while handling billions of requests with high availability.

### **Core Requirements**
- **Functional**: URL shortening, redirection, custom aliases, analytics
- **Non-Functional**: 100:1 read/write ratio, 500M URLs/month, 100ms latency
- **Scale**: Handle viral content and traffic spikes

### **The Architecture**

#### **1. URL Encoding Strategy**
```
Base62 Encoding (a-z, A-Z, 0-9):
- 6 characters = 62^6 = 56.8 billion URLs
- 7 characters = 62^7 = 3.5 trillion URLs

Example:
Long URL: https://www.example.com/very/long/path?param=value
Short URL: https://bit.ly/aB3xYz
```

#### **2. Key Generation Methods**

**Method 1: Counter-based**
```
Process:
1. Auto-incrementing counter in database
2. Convert number to base62
3. Counter: 125 → Base62: "1Z"
Pros: Simple, no collisions
Cons: Predictable, single point of failure
```

**Method 2: Random Generation**
```
Process:
1. Generate random base62 string
2. Check if already exists in database
3. If collision, regenerate
Pros: Unpredictable
Cons: Collision probability increases over time
```

**Method 3: Hash-based**
```
Process:
1. Hash(long_url + salt) → MD5/SHA256
2. Take first 6-7 characters
3. Convert to base62 if needed
Pros: Deterministic for same URL
Cons: Hash collisions possible
```

#### **3. Database Design**
```sql
-- URLs Table
CREATE TABLE urls (
  short_url VARCHAR(7) PRIMARY KEY,
  long_url TEXT NOT NULL,
  user_id INT,
  created_at TIMESTAMP,
  expires_at TIMESTAMP,
  click_count INT DEFAULT 0
);

-- Analytics Table
CREATE TABLE clicks (
  id BIGINT PRIMARY KEY,
  short_url VARCHAR(7),
  clicked_at TIMESTAMP,
  ip_address VARCHAR(45),
  user_agent TEXT,
  referrer TEXT
);
```

#### **4. Caching Strategy**
```
Multi-layer Caching:
1. Application Cache: Popular URLs in memory
2. Redis Cache: Distributed cache for hot URLs
3. CDN Cache: Cache redirect responses globally
4. Database Cache: Query result caching

Cache Policies:
- TTL: 24 hours for redirect mappings
- LRU: Evict least recently used URLs
- Write-through: Update cache on URL creation
```

### **System Components**

#### **1. URL Shortening Service**
```python
def shorten_url(long_url, user_id=None, custom_alias=None):
    # Validate URL format
    if not is_valid_url(long_url):
        raise InvalidURLError()
    
    # Check for existing mapping
    existing = db.get_by_long_url(long_url)
    if existing:
        return existing.short_url
    
    # Generate short code
    if custom_alias:
        short_code = custom_alias
    else:
        short_code = generate_short_code()
    
    # Store mapping
    db.store_mapping(short_code, long_url, user_id)
    cache.set(short_code, long_url, ttl=86400)
    
    return short_code
```

#### **2. URL Redirection Service**
```python
def redirect_url(short_code):
    # Check cache first
    long_url = cache.get(short_code)
    if long_url:
        analytics.record_click(short_code)
        return redirect(long_url, 301)
    
    # Fallback to database
    mapping = db.get_by_short_code(short_code)
    if not mapping:
        raise URLNotFoundError()
    
    # Update cache and redirect
    cache.set(short_code, mapping.long_url, ttl=86400)
    analytics.record_click(short_code)
    return redirect(mapping.long_url, 301)
```

### **Scaling Techniques**
1. **Database Sharding**: Partition by hash of short_code
2. **Read Replicas**: Multiple read-only database copies
3. **CDN Integration**: Cache redirects at edge locations
4. **Rate Limiting**: Prevent abuse and spam
5. **Asynchronous Analytics**: Process click data in background

### **Advanced Features**
- **Custom Domains**: bit.ly, yourdomain.ly
- **Link Analytics**: Click tracking, geographic data, referrers
- **Bulk Operations**: API for creating many short URLs
- **Link Management**: Edit, disable, set expiration dates
- **QR Codes**: Generate QR codes for short URLs

---

## 13. Amazon S3's Durability

### **The Problem: 99.999999999% Durability** 🛡️

**Background**: Amazon S3 (Simple Storage Service) promises "eleven 9s" of durability, meaning if you store 10 million objects, you might lose one object every 10,000 years.

### **What is Durability?**
**Durability**: Probability that data won't be lost over time
- 99.9% = 1 in 1,000 chance of loss per year
- 99.999999999% = 1 in 100 billion chance of loss per year

### **The Architecture**

#### **1. Redundant Storage**
```
Every Object Stored Multiple Times:
- Minimum 3 copies across different facilities
- Different availability zones (separate power/network)
- Automatic replication on upload
- Cross-region replication for additional protection
```

#### **2. Data Integrity Checking**
```
Continuous Verification:
1. Checksum calculated on upload
2. Periodic integrity scans
3. Automatic repair if corruption detected
4. Silent data corruption prevention
```

#### **3. Storage Classes for Different Needs**

**S3 Standard**
- 99.999999999% durability
- 99.99% availability
- 3+ copies across multiple AZs

**S3 Intelligent-Tiering**
- Automatic cost optimization
- Moves data between access tiers
- Same durability as Standard

**S3 Glacier**
- Long-term archival storage
- Lower cost, higher retrieval time
- Same durability guarantees

#### **4. Versioning and Backup**
```
Data Protection Features:
- Object versioning (keep multiple versions)
- Cross-region replication
- Point-in-time recovery
- MFA delete protection
```

### **Technical Implementation**

#### **1. Distributed Storage**
```
Object Storage Process:
1. Object uploaded to S3
2. Split into chunks if large
3. Each chunk replicated 3+ times
4. Stored across different physical locations
5. Metadata stored separately
```

#### **2. Erasure Coding**
```
Advanced Protection:
- Data split into fragments
- Parity information added
- Can reconstruct data even if multiple fragments lost
- More efficient than simple replication
```

#### **3. Consistency Model**
```
Strong Consistency (as of 2020):
- Read-after-write consistency for new objects
- Read-after-write consistency for overwrite PUTs and DELETEs
- No eventual consistency delays
```

### **Operational Excellence**

#### **1. Monitoring and Alerting**
- Continuous health monitoring
- Automated failure detection
- Proactive hardware replacement
- Performance monitoring

#### **2. Disaster Recovery**
- Multi-region architecture
- Automated failover capabilities
- Regular disaster recovery testing
- Geographic distribution

### **Real-World Results**
- **Billions of objects** stored safely
- **Trillions of requests** per month
- **Industry standard** for cloud storage
- **99.999999999% durability** achieved in practice

---

## 14. Redis Use Cases

### **The Problem: Beyond Just Caching** ⚡

**Background**: Redis (Remote Dictionary Server) started as a simple cache but evolved into a versatile "data structure server" that solves many different problems.

### **Core Redis Use Cases**

#### **1. Caching**
```python
# Cache database query results
def get_user_profile(user_id):
    # Check cache first
    cached = redis.get(f"user:{user_id}")
    if cached:
        return json.loads(cached)
    
    # Cache miss - query database
    user = db.query_user(user_id)
    redis.setex(f"user:{user_id}", 3600, json.dumps(user))
    return user
```

**Benefits**:
- 100x faster than database queries
- Reduced database load
- Better user experience

#### **2. Session Storage**
```python
# Store user session data
def store_session(session_id, user_data):
    redis.hset(f"session:{session_id}", mapping=user_data)
    redis.expire(f"session:{session_id}", 86400)  # 24 hours

def get_session(session_id):
    return redis.hgetall(f"session:{session_id}")
```

**Benefits**:
- Stateless web servers (easy to scale)
- Automatic session expiration
- Shared across multiple servers

#### **3. Rate Limiting**
```python
# Sliding window rate limiter
def is_rate_limited(user_id, limit=100, window=3600):
    key = f"rate_limit:{user_id}"
    current_count = redis.get(key) or 0
    
    if int(current_count) >= limit:
        return True
    
    # Increment and set expiry
    pipeline = redis.pipeline()
    pipeline.incr(key)
    pipeline.expire(key, window)
    pipeline.execute()
    
    return False
```

#### **4. Real-Time Analytics**
```python
# Count unique visitors using HyperLogLog
def track_visitor(page_url, visitor_ip):
    redis.pfadd(f"visitors:{page_url}", visitor_ip)

def get_unique_visitors(page_url):
    return redis.pfcount(f"visitors:{page_url}")
```

#### **5. Pub/Sub Messaging**
```python
# Real-time notifications
def send_notification(channel, message):
    redis.publish(channel, json.dumps(message))

def subscribe_to_notifications(channel):
    pubsub = redis.pubsub()
    pubsub.subscribe(channel)
    for message in pubsub.listen():
        process_notification(message['data'])
```

#### **6. Distributed Locking**
```python
# Prevent concurrent access to resources
def acquire_lock(resource_id, timeout=10):
    lock_key = f"lock:{resource_id}"
    identifier = str(uuid.uuid4())
    
    # Try to acquire lock
    if redis.set(lock_key, identifier, nx=True, ex=timeout):
        return identifier
    return None

def release_lock(resource_id, identifier):
    lock_key = f"lock:{resource_id}"
    # Only release if we own the lock
    lua_script = """
    if redis.call("get", KEYS[1]) == ARGV[1] then
        return redis.call("del", KEYS[1])
    else
        return 0
    end
    """
    return redis.eval(lua_script, 1, lock_key, identifier)
```

#### **7. Leaderboards**
```python
# Gaming leaderboards using sorted sets
def update_score(player_id, score):
    redis.zadd("leaderboard", {player_id: score})

def get_top_players(count=10):
    return redis.zrevrange("leaderboard", 0, count-1, withscores=True)

def get_player_rank(player_id):
    rank = redis.zrevrank("leaderboard", player_id)
    return rank + 1 if rank is not None else None
```

### **Advanced Redis Data Structures**

#### **1. Streams (Message Queues)**
```python
# Producer
def add_to_stream(stream_name, data):
    redis.xadd(stream_name, data)

# Consumer
def consume_stream(stream_name, consumer_group, consumer_name):
    redis.xgroup_create(stream_name, consumer_group, id='0', mkstream=True)
    messages = redis.xreadgroup(consumer_group, consumer_name, {stream_name: '>'})
    return messages
```

#### **2. Time Series Data**
```python
# Store and query time-series data
def record_metric(metric_name, timestamp, value):
    redis.ts().add(metric_name, timestamp, value)

def get_metric_range(metric_name, start_time, end_time):
    return redis.ts().range(metric_name, start_time, end_time)
```

#### **3. Geospatial Indexing**
```python
# Store and query location data
def add_location(key, longitude, latitude, member):
    redis.geoadd(key, longitude, latitude, member)

def find_nearby(key, longitude, latitude, radius_km):
    return redis.georadius(key, longitude, latitude, radius_km, unit='km')
```

### **Why Redis is Powerful**
1. **In-Memory Speed**: Microsecond latency
2. **Rich Data Types**: More than just key-value
3. **Atomic Operations**: Thread-safe operations
4. **Persistence**: Can survive restarts
5. **Clustering**: Horizontal scaling support
6. **Lua Scripting**: Complex operations server-side

---

## 🎓 System Design Principles Summary

### **1. Scalability Patterns**
- **Vertical Scaling**: Add more power to existing servers
- **Horizontal Scaling**: Add more servers to handle load
- **Caching**: Store frequently accessed data in fast storage
- **Load Balancing**: Distribute requests across multiple servers
- **Database Sharding**: Split database across multiple servers
- **Microservices**: Break application into independent services

### **2. Reliability Patterns**
- **Redundancy**: Multiple copies of critical components
- **Failover**: Automatic switching to backup systems
- **Circuit Breakers**: Prevent cascade failures
- **Bulkhead Pattern**: Isolate resources to prevent total failure
- **Retry Mechanisms**: Handle transient failures gracefully
- **Health Checks**: Monitor system components continuously

### **3. Performance Patterns**
- **CDN**: Cache static content globally
- **Database Indexing**: Speed up query performance
- **Connection Pooling**: Reuse database connections
- **Asynchronous Processing**: Handle long-running tasks separately
- **Batch Processing**: Group operations for efficiency
- **Precomputation**: Calculate expensive operations ahead of time

### **4. Data Patterns**
- **ACID Properties**: Ensure data consistency and reliability
- **Event Sourcing**: Store all changes as sequence of events
- **CQRS**: Separate read and write data models
- **Data Partitioning**: Split data across multiple storage systems
- **Replication**: Keep multiple copies of data synchronized
- **Eventual Consistency**: Accept temporary inconsistency for performance

## 📚 Next Steps for Learning

### **Practice Projects**
1. **Build a URL Shortener**: Start with basic functionality, add analytics
2. **Create a Chat Application**: Implement real-time messaging with WebSockets
3. **Design a Social Media Feed**: Handle millions of posts and user interactions
4. **Build a Distributed Cache**: Implement your own Redis-like system
5. **Create a Load Balancer**: Route traffic across multiple backend servers

### **Deep Dive Topics**
1. **Distributed Systems**: Learn about consensus algorithms (Raft, Paxos)
2. **Database Internals**: Understand how databases work under the hood
3. **Network Protocols**: Study TCP/IP, HTTP/2, WebSockets
4. **Security**: Learn about authentication, authorization, and encryption
5. **Monitoring**: Implement comprehensive observability solutions

### **Recommended Reading**
1. **"Designing Data-Intensive Applications"** by Martin Kleppmann
2. **"System Design Interview"** by Alex Xu
3. **"Building Microservices"** by Sam Newman
4. **"High Performance MySQL"** by Baron Schwartz
5. **"Redis in Action"** by Josiah L. Carlson

---

**Remember**: System design is about making trade-offs. There's no perfect solution, only solutions that are optimized for specific requirements and constraints. Start simple, measure performance, and scale based on actual needs rather than hypothetical requirements.

Each of these case studies represents years of engineering evolution and millions of dollars in development. The key is to understand the principles and patterns, then apply them appropriately to your own systems.

Good luck on your system design journey! 🚀
